import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PopupAddTagUserComponent } from './popup-add-tag-user.component';
import { AmisPopupModule } from 'src/common/components/amis-popup/amis-popup.module';
import { AmisButtonModule } from 'src/common/components/amis-button/amis-button.module';
import { FormsModule } from '@angular/forms';
import { TranslateModule } from '@ngx-translate/core';


@NgModule({
  declarations: [PopupAddTagUserComponent],
  imports: [
    CommonModule,
    AmisButtonModule,
    AmisPopupModule,
    FormsModule,
    TranslateModule
  ],
  exports: [PopupAddTagUserComponent]
})
export class PopupAddTagUserModule { }
