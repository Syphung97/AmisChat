import { Component, OnInit, ViewChild, Input, ElementRef, EventEmitter, Output } from '@angular/core';
import { FormMode } from 'src/common/enum/form-mode.enum';
import { ButtonColor } from '../../enum/common/button-color.enum';
import { ButtonType } from '../../enum/common/button-type.enum';
import { TagService } from 'src/app/services/tag/tag.service';
import { TransferDataService } from 'src/app/services/base/transfer-data.service';
import { AmisTranslationService } from 'src/common/services/amis-translation.service';
import { Tag } from '../../models/contact/Tag';
import { TagUser } from '../../models/contact/TagUser';
import { KeyCode } from 'src/common/enum/key-code.enum';
@Component({
  selector: 'app-popup-add-tag-user',
  templateUrl: './popup-add-tag-user.component.html',
  styleUrls: ['./popup-add-tag-user.component.scss']
})
export class PopupAddTagUserComponent implements OnInit {

  //#region  Properties
  _title = this.translateSV.getValueByKey("TAG_ADD_TAG");
  @ViewChild("newTag", { static: false })
  tagInput: ElementRef
  @Input() visiblePopup: boolean;


  @Input() listSelectedContact;

  formMode = FormMode.Insert;



  tagName = "";

  //Màu của button
  buttonColor = ButtonColor;
  //Loại butotn
  buttonType = ButtonType;

  invalidInput = false;

  @Output() closed = new EventEmitter<boolean>();
  //#endregion
  constructor(
    private tagSV: TagService,
    private tranferSV: TransferDataService,
    private translateSV: AmisTranslationService
  ) { }

  ngOnInit(): void {
  }

  onClose() {
    this.visiblePopup = false;
    this.closed.emit(false);
  }

  onShown(input) {
    input.focus();
  }
  cancel() {
    this.visiblePopup = false;
    this.closed.emit(false);
  }

  /**
   * Thêm thẻ
   *
   * @memberof PopupAddTagUserComponent
   */
  addOrUpdateTag() {
    if (this.tagName?.trim()) {
      const tag = new Tag();
      tag.TagName = this.tagName.trim();
      tag.State = this.formMode;

      const tagUsers = [];
      this.listSelectedContact?.forEach(el => {

        const tagUser = new TagUser();
        tagUser.TagName = this.tagName;
        tagUser.ContactID = el.ContactID;
        tagUser.State = FormMode.Insert;
        tagUsers.push(tagUser);
      });
      tag.ListTagUser = tagUsers;
      this.tagSV.save(tag).subscribe(data => {
        if (data?.Success) {
          sessionStorage.removeItem("AMIS_Contact_AllTag");
          this.tranferSV.reloadSidebar();
          this.tranferSV.showSuccessToast(this.translateSV.getValueByKey("TAG_ADD_DONE"));
          this.visiblePopup = false;
          this.closed.emit(true);
        }
        else if (data?.ValidateInfo && data?.ValidateInfo.length > 0) {
          this.tranferSV.showErrorToast(this.translateSV.getValueByKey(data.ValidateInfo[0].ErrorMessage));
        }
        else {
          this.tranferSV.showSuccessToast(this.translateSV.getValueByKey("TAG_ADD_FAIL"));
        }
      },
        err => {
          this.tranferSV.showErrorToast(this.translateSV.getValueByKey("COMMON_SYSTEM_ERROR"));
        })
    }
    else {
      this.invalidInput = true;
      this.tagInput.nativeElement.focus();
    }
  }

  handleKeyUp(event) {
    if(event?.keyCode == KeyCode.Enter) {
      this.addOrUpdateTag();
    }
  }
}
