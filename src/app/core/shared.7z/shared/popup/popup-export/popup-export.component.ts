import { Component, OnInit, Input, ViewChild, Output, EventEmitter } from '@angular/core';
import { ButtonColor } from '../../enum/common/button-color.enum';
import { ButtonType } from '../../enum/common/button-type.enum';
import { DxListComponent } from 'devextreme-angular';
import { LayoutConfigService } from 'src/app/services/layout-config/layout-config.service';
import { TagService } from 'src/app/services/tag/tag.service';

@Component({
  selector: 'contact-popup-export',
  templateUrl: './popup-export.component.html',
  styleUrls: ['./popup-export.component.scss']
})
export class PopupExportComponent implements OnInit {

  @ViewChild(DxListComponent, { static: false }) list: DxListComponent;
  //Màu của button
  buttonColor = ButtonColor;
  //Loại butotn
  buttonType = ButtonType;
  //Trường hiển thị popup
  @Input() visiblePopup: boolean;
  //Kiểu chọn
  selectionModeValue = "multiple";

  @Output()
  afterExport: EventEmitter<any> = new EventEmitter<any>();

  @Output() closed = new EventEmitter<boolean>();

  //Mảng các thông tin xuất khẩu
  @Input()
  information: any = [
  ];
  //Mảng các thông tin xuất khẩu được chọn
  @Input() selectedInfo: any = [
  ];

  //Mảng các nhãn để xuất khẩu
  @Input() listExportCategory: any = [

  ];
  //Lựa chọn xuất khẩu đang được chọn
  @Input() currentExportCategory = {
    OrganizationUnitID: "Tất cả liên hệ",
    OrganizationUnitName: "Tất cả liên hệ"
  };

  //Mảng các lựa chọn xuất khẩu
  listExportOption = [
    {
      Caption: "Danh sách đã chọn",
      FieldName: "SelectedList"
    },
    {
      Caption: "Theo nhãn",
      FieldName: "ByTag"
    }
  ];

  cloneItems = [];

  //Lựa chọn xuất khẩu đang được chọn
  currentExportOption: any;

  tagInfo;
  isByTag = false;
  constructor(
    private tagSV: TagService,

  ) { }

  ngOnInit(): void {
    this.currentExportOption = this.listExportOption[0];
    this.sortOrderInfo(this.information, this.selectedInfo);
    this.tagInfo = this.currentExportCategory;
  }
  /**
   * Sắp xếp lại thứ tự hiển thị trên grid
   * Created by: dthieu 13-05-2020
   */
  sortOrderInfo(information, selectedInfo) {
    const me = this;
    // Sắp xếp lại thứ tự các item đc chọn
    let tmpColumns = [];
    let selectedCaption;
    if (this.selectedInfo?.length) {
      selectedCaption = this.selectedInfo.map(e => e.OrganizationUnitName);
    }
    const tmpSelectColumn = information.filter(
      function (e) {
        return this.indexOf(e.OrganizationUnitName) > -1;
      },
      selectedCaption
    );

    this.selectedInfo = tmpSelectColumn;
    const tmpHideColumn = information.filter(
      function (e) {
        return this.indexOf(e.OrganizationUnitName) < 0;
      },
      selectedCaption
    );  // Các item không được chọn
    tmpColumns.push(...tmpSelectColumn);
    tmpColumns.push(...tmpHideColumn);
    me.information = tmpColumns;
  }

  selecteExportOption(e, item) {
    this.currentExportOption = item;
    if (item.FieldName === 'ByTag') {
      this.isByTag = true;
    } else {
      this.isByTag = false;
    }
  }

  exportContact(){
    let selectedKeys = this.list.instance.option('selectedItemKeys');
    const param = {
      tagID: this.tagInfo,
      selectData: selectedKeys,
      isByTag: this.isByTag
    };
    this.afterExport.emit(param);
    this.onClose();
  }

  onClose() {
    this.visiblePopup = false;
    this.closed.emit(false);
  }

  /**
   * Xử lý chọn bản ghi
   * Created by ltanh1 02/07/2020
   */
  selectItem(key) {
    const selectedKeys = this.list.instance.option('selectedItemKeys');
  }

  /**
   * Chọn thẻ xuất khẩu
   * Created by ltanh1 02/07/2020
   */
  chooseTag(e) {
    let data = this.listExportCategory.find(x => x.OrganizationUnitID === e.value);
    this.tagInfo = data;
  }
}
