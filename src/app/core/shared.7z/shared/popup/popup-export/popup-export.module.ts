import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TranslateModule } from '@ngx-translate/core';

import { PopupExportComponent } from './popup-export.component';
import { AmisPopupModule } from 'src/common/components/amis-popup/amis-popup.module';
import { AmisButtonModule } from 'src/common/components/amis-button/amis-button.module';
import { DxListModule, DxSelectBoxModule } from 'devextreme-angular';


@NgModule({
  declarations: [PopupExportComponent],
  imports: [
    CommonModule,
    AmisPopupModule,
    AmisButtonModule,
    DxListModule,
    DxSelectBoxModule,
    TranslateModule
  ],
  exports: [
    PopupExportComponent,
    
  ]
})
export class PopupExportModule { }
