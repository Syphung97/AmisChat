import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PopupQrCodeComponent } from './popup-qr-code.component';
import { AmisPopupModule } from 'src/common/components/amis-popup/amis-popup.module';
import { AmisNoSanitizeModule } from 'src/common/pipes/amis-no-sanitize/amis-no-santinize.module';
import { TranslateModule } from '@ngx-translate/core';



@NgModule({
  declarations: [PopupQrCodeComponent],
  imports: [
    CommonModule,
    AmisPopupModule,
    AmisNoSanitizeModule,
    TranslateModule
  ],
  exports: [PopupQrCodeComponent]
})
export class PopupQrCodeModule { }
