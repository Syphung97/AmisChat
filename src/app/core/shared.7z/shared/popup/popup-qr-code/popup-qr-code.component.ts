import { Component, EventEmitter, Input, OnInit, Output } from "@angular/core";
import { TransferDataService } from "src/app/services/base/transfer-data.service";
import { AmisTranslationService } from "src/common/services/amis-translation.service";
import { DataQRCode } from "../../models/contact/data-qr-code";
declare var MISAQRCode: any;
@Component({
  selector: "app-popup-qr-code",
  templateUrl: "./popup-qr-code.component.html",
  styleUrls: ["./popup-qr-code.component.scss"],
})
export class PopupQrCodeComponent implements OnInit {
  @Input() visiblePopup;
  @Output() closePopup = new EventEmitter();
  _employee;
  @Input() set employee(data) {
    this._employee = data;
    // this.dataQRCode = { "FullName": "Nguyen Đức Quảng", "LastName": "Đức Quảng", "FirstName": "Nguyễn", "Mobile": "0389926059", "OfficeTel": "0243 122 222", "Organization": "MISA JSC", "Website": "misa.vn", "Email": "ndquang@software.misa.com.vn" }

    this.generateQRCode();
  }
  _title = "";

  contentQRCode: any;

  dataQRCode = new DataQRCode();
  constructor(
    private tranferSV: TransferDataService,
    private translateSV: AmisTranslationService
  ) {}

  ngOnInit(): void {
    this._title = this.translateSV.getValueByKey("QRCODE_TITLE");
  }

  /**
   * Mapping dataQR Code
   *
   * @memberof PopupQrCodeComponent
   */
  mapData(data): void {
    this.dataQRCode.FullName = data.FullName;
    this.dataQRCode.LastName = data.LastName;
    this.dataQRCode.FirstName = data.FirstName;
    this.dataQRCode.Mobile = data.Mobile;
    this.dataQRCode.OfficeTel = data.OfficeTel;
    this.dataQRCode.Organization = data.Organization;
    this.dataQRCode.Website = data.Website;
    this.dataQRCode.Email = data.Email;
  }

  generateQRCode(): void {
    this.contentQRCode = MISAQRCode.Client.createVCard(
      this._employee.dataQRCode,
      120,
      "svg"
    );
  }

  onClose(): void {
    this.visiblePopup = false;
    this.closePopup.emit();
  }

  /**
   * copyLinkQRCode
   *
   * @memberof PopupQrCodeComponent
   */
  copyLinkQRCode(): void {
    const el = MISAQRCode.Google.createVCard(this._employee.dataQRCode, 240);
    const link = el.children[0].getAttribute("src");

    const selBox = document.createElement("textarea");
    selBox.value = link;
    document.body.appendChild(selBox);
    selBox.focus();
    selBox.select();
    document.execCommand("copy");
    document.body.removeChild(selBox);
    this.tranferSV.showSuccessToast(
      this.translateSV.getValueByKey("COPY_DONE")
    );
  }

  /**
   * downloadQRCode
   *
   * @memberof PopupQrCodeComponent
   */
  downloadQRCode(): void {
    const svg = MISAQRCode.Client.createVCard(
      this._employee.dataQRCode,
      120,
      "svg"
    );
    MISAQRCode.Fn.downloadSVG(svg, this._employee.FullName);

    const canvas = MISAQRCode.Client.createVCard(
      this._employee.dataQRCode,
      120,
      "canvas"
    );
    MISAQRCode.Fn.downloadPNG(canvas, this._employee.FullName);
  }
}
