import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { AmisTranslationService } from 'src/common/services/amis-translation.service';
import { ButtonColor } from '../../enum/common/button-color.enum';
import { ButtonType } from '../../enum/common/button-type.enum';


@Component({
  selector: 'contact-popup-email-selection',
  templateUrl: './popup-email-selection.component.html',
  styleUrls: ['./popup-email-selection.component.scss']
})
export class PopupEmailSelectionComponent implements OnInit {

  //Màu của button
  buttonColor = ButtonColor;
  //Loại butotn
  buttonType = ButtonType;
  constructor(
    private translateSV: AmisTranslationService
  ) { }
  //Danh sách các email option
  emailOption: any[];
  //Option được chọn
  currentEmailOption: any;

  @Output() closed = new EventEmitter<boolean>();

  @Input() visiblePopup: boolean;

  ngOnInit(): void {
    this.getEmailOption();
  }

  /**
   * Hàm chọn option gửi email
   * Created by: hgvinh 23/05/2020
   * @param e event
   * @param item item truyền vào
   */
  selecteEamilOption(e, item) {
    this.currentEmailOption = item;
  }

  /**
   * ẩn popup
   * created by: hgvinh 23/05/2020
   */
  hidePopup() {
    this.visiblePopup = false;
    console.log("Ẩn")
  }
  /**
   * hàm xử lí khi ẩn popup
   * created by: hgvinh 23/05/2020
   */
  onClose() {
    this.currentEmailOption = null;
    this.closed.emit(false);
  }

  /**
   * gửi email
   * created by: hgvinh 23/05/2020
   */
  sendEmail() {
    console.log("Gửi")
  }

  /**
   * lấy các email option
   * created by: hgvinh 23/05/2020
   */
  getEmailOption() {
    this.emailOption = [
      {
        Caption: this.translateSV.getValueByKey("Email"),
        FieldName: "Email"
      },
      {
        Caption: this.translateSV.getValueByKey("OfficeEmail"),
        FieldName: "WorkEmail"
      },
      {
        Caption: this.translateSV.getValueByKey("OtherEmail"),
        FieldName: "OtherEmail"
      },
    ];
  }
}
