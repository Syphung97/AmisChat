import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TranslateModule } from '@ngx-translate/core';

import { PopupEmailSelectionComponent } from './popup-email-selection.component';
import { AmisPopupModule } from 'src/common/components/amis-popup/amis-popup.module';
import { AmisButtonModule } from 'src/common/components/amis-button/amis-button.module';


@NgModule({
  declarations: [PopupEmailSelectionComponent],
  imports: [
    CommonModule,
    AmisPopupModule,
    AmisButtonModule,
    TranslateModule
  ],
  exports:[
    PopupEmailSelectionComponent
  ]
})
export class PopupEmailSelectionModule { }
