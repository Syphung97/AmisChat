import { Component, OnInit, Input, Output, EventEmitter, ViewChild, ElementRef } from '@angular/core';
import { ButtonColor } from '../../enum/common/button-color.enum';
import { ButtonType } from '../../enum/common/button-type.enum';
import { TagService } from 'src/app/services/tag/tag.service';
import { FormMode } from 'src/common/enum/form-mode.enum'
import { Tag } from '../../models/contact/Tag';
import { TransferDataService } from 'src/app/services/base/transfer-data.service';
import { AmisTranslationService } from 'src/common/services/amis-translation.service';
import { KeyCode } from 'src/common/enum/key-code.enum';
@Component({
  selector: 'contact-popup-add-tag',
  templateUrl: './popup-add-tag.component.html',
  styleUrls: ['./popup-add-tag.component.scss']
})
export class PopupAddTagComponent implements OnInit {

  //#region  Properties

  @ViewChild("newTag", {static: false})
  tagInput: ElementRef
  @Input() visiblePopup: boolean;

  @Input() formMode = FormMode.Insert;

  @Input() maxSortOrder = 0;

  _title = "";
  @Input() set title(value) {
    if (value !== this._title) {
      this._title = value;
    }
  }
  tagName = "";
  @Input() tagObject: Tag;
  //Màu của button
  buttonColor = ButtonColor;
  //Loại butotn
  buttonType = ButtonType;

  invalidInput = false;

  @Output() closed = new EventEmitter<boolean>();
  //#endregion
  constructor(
    private tagSV: TagService,
    private tranferSV: TransferDataService,
    private translateSV: AmisTranslationService
  ) { }

  ngOnInit(): void {
    if(this.tagObject?.TagName) {
      this.tagName = this.tagObject.TagName;
    }
  }

  /**
   * Hàm hủy thêm
   * Created by: hgvinh 23/05/2020
   */
  cancel(value) {
    value.value = "";
    this.visiblePopup = false;
    this.closed.emit(false);
  }

  /**
   * Hàm thêm mới nhãn
   * @param value tên nhãn mới
   */
  addOrUpdateTag() {
    if (this.tagName?.trim()) {

      if (this.formMode === FormMode.Insert) {
        this.addNewTag()
      }
      else if (this.formMode === FormMode.Update) {
        this.updateTag();
      }

    }
    else {
      this.invalidInput = true;
      this.tagInput.nativeElement.focus();
    }
  }

  /**
   * Thêm mới tag
   *
   * @memberof PopupAddTagComponent
   * CREATED : PTSY
   */
  addNewTag() {
    const tag = new Tag();
    tag.TagName = this.tagName.trim();
    tag.SortOrder = this.maxSortOrder + 1;
    tag.State = this.formMode;
    this.tagSV.save(tag).subscribe(data => {
      if (data?.Success) {
        sessionStorage.removeItem("AMIS_Contact_AllTag");
        this.tranferSV.showSuccessToast(this.translateSV.getValueByKey("TAG_ADD_DONE"));
        this.visiblePopup = false;
        this.closed.emit(true);
      }
      else if(data?.ValidateInfo && data?.ValidateInfo.length > 0){
        this.tranferSV.showErrorToast(this.translateSV.getValueByKey(data.ValidateInfo[0].ErrorMessage));
      }
      else {
        this.tranferSV.showSuccessToast(this.translateSV.getValueByKey("TAG_ADD_FAIL"));
      }
    },
      err => {
        this.tranferSV.showErrorToast(this.translateSV.getValueByKey("COMMON_SYSTEM_ERROR"));
      })
  }

  /**
   * Update Tag
   *
   * @memberof PopupAddTagComponent
   * Created: PTSY
   */
  updateTag() {
    this.tagObject.TagName = this.tagName.trim();
    this.tagObject.State = this.formMode;
    this.tagSV.save(this.tagObject).subscribe(data => {
      if (data?.Success) {
        sessionStorage.removeItem("AMIS_Contact_AllTag");
        this.tranferSV.showSuccessToast(this.translateSV.getValueByKey("TAG_UPDATE_DONE"));
        this.visiblePopup = false;
        this.closed.emit(true);
      }
      else if(data?.ValidateInfo && data?.ValidateInfo.length > 0){
        this.tranferSV.showErrorToast(this.translateSV.getValueByKey(data.ValidateInfo[0].ErrorMessage));
      }
      else {
        this.tranferSV.showSuccessToast(this.translateSV.getValueByKey("TAG_ADD_FAIL"));
      }
    },
      err => {
        this.tranferSV.showErrorToast(this.translateSV.getValueByKey("COMMON_SYSTEM_ERROR"));
      })
  }
  onClose() {
    this.visiblePopup = false;
    this.closed.emit(false);
  }

  onShown(input) {
    input.focus();
  }

  handleKeyUp(event) {
    if(event?.keyCode == KeyCode.Enter) {
      this.addOrUpdateTag();
    }
  }
}
