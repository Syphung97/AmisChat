import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PopupSelectDataComponent } from './popup-select-data.component';
import { AmisPopupModule } from 'src/common/components/amis-popup/amis-popup.module';
import { AmisButtonModule } from 'src/common/components/amis-button/amis-button.module';
import { DxTextBoxModule, DxDropDownBoxModule, DxDataGridModule, DxTreeViewModule } from 'devextreme-angular';
import { TranslateModule } from '@ngx-translate/core';
import { PagingModule } from '../../components/paging/paging.module';

@NgModule({
  declarations: [PopupSelectDataComponent],
  imports: [
    CommonModule,
    AmisPopupModule,
    AmisButtonModule,
    DxTextBoxModule,
    TranslateModule,
    DxDropDownBoxModule,
    PagingModule, 
    DxDataGridModule, 
    DxTreeViewModule,
    TranslateModule
  ],
  exports: [
    PopupSelectDataComponent
  ]
})
export class PopupSelectDataModule { }
