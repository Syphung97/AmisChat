import { Component, OnInit, Input, Output, EventEmitter, ViewChild } from '@angular/core';
import { ButtonColor } from '../../enum/common/button-color.enum';
import { TransferDataService } from 'src/app/services/base/transfer-data.service';
import { AmisDataService } from 'src/common/services/amis-data.service';
import { AmisTranslationService } from 'src/common/services/amis-translation.service';
import { DxDataGridComponent, DxTextBoxComponent, DxDropDownBoxComponent } from 'devextreme-angular';
import { EmployeeService } from 'src/app/services/employee/employee.service';
import { OrganizationUnitService } from 'src/app/services/organizaion-unit/organization-unit.service';
import { AmisCommonUtils } from 'src/common/fn/common-utils';
import { AvatarService } from 'src/app/services/user/avatar.service';

declare var $: any;

@Component({
  selector: 'contact-popup-select-data',
  templateUrl: './popup-select-data.component.html',
  styleUrls: ['./popup-select-data.component.scss']
})
export class PopupSelectDataComponent implements OnInit {

  //khai báo grid
  @ViewChild('popupGrid', { static: false })
  popupGrid: DxDataGridComponent;
  //khai báo textbox
  @ViewChild('searchTextBox', { static: false })
  searchTextBox: DxTextBoxComponent;
  @ViewChild('dropdown', { static: false })
  dropdown: DxDropDownBoxComponent;

  //trường hiển thị popup
  @Input() visiblePopup: boolean = false;
  //kết quả được chọn
  @Output() outSelectedRecord: EventEmitter<any> = new EventEmitter<any>();
  //đóng popup
  @Output() closePopup: EventEmitter<any> = new EventEmitter<any>();
  //off set của popup
  offsetY = "0 100px";
  //tổng số bản ghi
  totalRecord: number;
  //màu button
  buttonColor = ButtonColor;
  //từ khóa tìm kiếm
  searchName: string;
  //các hàng được chọn
  selectedRow: any[] = [];
  //dữ liệu đổ lên grid
  dataSource: any = [];
  //có phải click phân trang k
  isClearSelect: boolean = false;
  //thời gian trễ tìm kiếm
  timeSearch: any;

  treeBoxValueOrga = [];
  isUserAppEM = false;
  listOrganization;

  listOrgaID: string[];
  _filterQuery = "";

  _pageIndex = 1;

  _pageSide = 10;

  //tham số lấy dữ liệu
  paramRequest = {
    "CustomParam": { "OrganizationUnitID": EmployeeService.userInfo.OrganizationUnitID },
    "PageIndex": this._pageIndex,
    "PageSize": this._pageSide,
    "Filter": "",
    "QuickSearch": {
      "Columns": ["FullName", "EmployeeCode", "OfficeEmail", "Mobile"],
      "SearchValue": ""
    },
    "Sort": window.btoa(`[{"selector":"LastName","desc":"false"}, {"selector":"FirstName","desc":"false"}]`)
  }
  constructor(
    private amisTranslateSV: AmisTranslationService,
    private transferData: TransferDataService,
    public httpBase: AmisDataService,
    private employeeSV: EmployeeService,
    private organizationUnitSV: OrganizationUnitService,
    private userAvatarSV: AvatarService
  ) {
    this.checkUserAppEM();
  }

  ngOnInit(): void {
    this.getAllOrganization();
    this.getData();
  }
  /**
   * hàm check xem có dử dụng app hồ sơ không
   *
   * @memberof PopupSelectDataComponent
   * vbcong 20/07/2020
   */
  checkUserAppEM(){
    const userInfo = EmployeeService.userInfo;
    if (!!userInfo) {
      // const userInfoObj = JSON.parse(userInfo);
      if(userInfo?.IsUseAppEP){
        this.isUserAppEM = true;
      }
    }
  }
  /**
   * hàm lấy dữ liệu theo param
   * created by: hgvinh 29/05/2020
   */
  getData() {
    this.employeeSV.getEmployeeData(
      this.paramRequest
    ).subscribe(data => {
      if (data?.Success) {
        this.dataSource = data?.Data.PageData;
        this.dataSource.forEach(ele => {
          ele.Avatar = this.userAvatarSV.getAvatar(ele.AvatarID)
        });
        this.totalRecord = data.Data.Total;
        let iDArray = this.selectedRow.map(e => e["ConvertID"]); // Lấy danh sách bản ghi đã được chọn
        let selectedRowTemp = this.dataSource.filter(e => iDArray.indexOf(e["ConvertID"]) > -1); // Lấy những bản ghi được chọn ở grid hiện tại
        setTimeout(() => {
          this.popupGrid.instance.selectRows(selectedRowTemp, false); //thực hiện chọn grid
          setTimeout(() => {
            this.isClearSelect = false;
          }, 300);
        }, 100);
      }

    })
  }
  /**
   * Hàm xử lí khi xóa trắng ô input
   * created by: hgvinh 29/05/2020
   */
  changeTextBoxValue(e) {
    if (e.event && e.event.type == "dxclick") {
      this.paramRequest.QuickSearch.SearchValue = "";
      this.paramRequest.PageIndex = 1;
      this.getData();
      this.isClearSelect = true;
    }
  }
  /**
   * Hàm xử lí lấy dữ liệu khi gõ input
   * created by: hgvinh 29/05/2020
   */
  onKeyupSearchBox() {
    clearTimeout(this.timeSearch);
    this.timeSearch = setTimeout(() => {
      var inputVal = this.searchTextBox.text
      if (inputVal) inputVal = inputVal.trim();
      if (inputVal != this.searchName) {
        this.searchName = inputVal;
        this.paramRequest.QuickSearch.SearchValue = this.searchName;
        this.paramRequest.PageIndex = 1;
        this.getData();
        this.isClearSelect = true;
      }
    }, 500);
  }
  /**
   * Hàm xử lí khi bấm nút phân trang
   * created by: hgvinh 29/05/2020
   * @param event sự kiện bấm nút
   */
  handleOnPagingChanged(event) {
    this._pageIndex = event?.PAGE_INDEX;
    this._pageSide = event?.PAGE_SIZE;
    this.updateRequestParams();
    this.getData();
    this.isClearSelect = true;
  }
  /**
   * Hàm update lại tham số truyền lên
   * created by: hgvinh 29/05/2020
   */
  updateRequestParams() {
    this.paramRequest.PageIndex = this._pageIndex;
    this.paramRequest.PageSize = this._pageSide;
    this.paramRequest.QuickSearch.SearchValue = this.searchName;
    this.paramRequest.Filter = this._filterQuery;
  }
  /**
   * Hàm xử lí khi ấn nút chọn
   * created by: hgvinh 29/05/2020
   */
  selectEmployee() {
    this.visiblePopup = false
    this.outSelectedRecord.emit(this.selectedRow)
  }
  /**
   * Hàm xử lí thay đổi khi chọn nhân viên trên grid
   * created by: hgvinh 29/05/2020
   */
  selectedRowKeysChange(e) {
    if (!this.isClearSelect) {
      if (e.currentSelectedRowKeys.length > 0) {
        let listID = this.selectedRow.map(e => e["ConvertID"]);
        e.currentSelectedRowKeys.forEach(element => {
          if (listID.indexOf(element["ConvertID"]) < 0) {
            this.selectedRow.push(element);
          }
        });
      }
      if (e.currentDeselectedRowKeys.length != 0) {
        let deleteID = e.currentDeselectedRowKeys.map(e => e["ConvertID"]);
        this.selectedRow.forEach(ele => {
          if (deleteID.indexOf(ele["ConvertID"]) > -1) {
            this.selectedRow = this.selectedRow.filter(e => e["ConvertID"] != ele["ConvertID"]);
          }
        });
      }
    }
  }
  /**
   * Hàm bỏ chọn nhân viên
   * created by: hgvinh 29/05/2020
   */
  unSelectAll() {
    this.popupGrid.instance.clearSelection();
    this.selectedRow = [];
  }

  onClosePopup(){
    this.visiblePopup = false;
    this.closePopup.emit(false);
  }

  /**
   * Lấy cơ cấu tổ chức công ty
   */
  getAllOrganization() {
    this.organizationUnitSV.getAllOrganizationByUser().subscribe(res => {
      if (res && res.Success) {
        this.listOrganization = this.buildTreeDataListOrganizaiton(res.Data);
      }
    })
  }

  /**
   * hàm build danh sách dữ liệu sử dụng cho cây cơ cấu tổ chức
   * @param {any} data
   * @memberof RecruitmentListComponent
   * dtnam1 06/0/2020
   */
  buildTreeDataListOrganizaiton(listData) {
    if (listData && listData.length > 0) {

      const listAllParent = this.findAllParent(listData);
      if (listAllParent && listAllParent.length > 0) {
        const parentID = listAllParent[0].OrganizationUnitID;
        this.treeBoxValueOrga.push(parentID);
        listAllParent.forEach(el => {
          const temp = listData.find(x => x.MISACode === el.MISACode);
          if (temp) {
            temp.ParentID = null;
          }
        });
      }
    }
    return listData;
  }

  /**
   * Tìm tất cả các node tổng
   * dtnam1 06/0/2020
   * @param listData : misaCode của đơn vị bất kỳ
   */
  findAllParent(listData) {
    const listParent = [];
    listData.forEach(item => {
      if (item.MISACode && item.MISACode.length > 8) {
        const listCode = item.MISACode.split('/');
        listCode.splice(listCode.length - 2, 1);
        const miCoParent = listCode.join('/');
        const itemPar = listData.find(x => x.MISACode === miCoParent);
        if (!itemPar) {
          item.IsExpanded = true;
          listParent.push(item);
        }
      } else {
        item.IsExpanded = true;
        listParent.push(item);
      }
    });
    return listParent;
  }
  syncTreeViewSelection($event) {

  }

  /**
   * hàm chọn key tree cơ cấu phòng ban
   *
   * @param {any} e
   * @memberof RecruitmentListComponent
   * dtnam1 01/06/2020
   */
  treeView_itemSelectionChanged(e) {
    if (e) {
      const nodes = e.component.getNodes();
      this.dropdown.instance.close();
      this.treeBoxValueOrga = e.itemData.OrganizationUnitID;
      const misaCodeSelect = e.itemData.MISACode;
      const listOrgaSelect = this.listOrganization.filter(item => {
        return item.MISACode.startsWith(misaCodeSelect) === true;
      });
      this.listOrgaID = [];
      if (listOrgaSelect && listOrgaSelect.length > 0) {
        listOrgaSelect.forEach(item => {
          this.listOrgaID.push(item.OrganizationUnitID);
        });
      }
    }
    this.buildFilterSubmit();
  }

  /**
     * build cấu điều kiện lọc trên thanh công cụ
     *
     * @memberof HrmProfileToolbarComponent
     * dtnam1 01/06/2020
     */
  buildFilterSubmit() {
    const filterParam = {
      ListOrganizationUnitID: this.listOrgaID
    };
    this._filterQuery = AmisCommonUtils.Base64Encode(`[["OrganizationUnitID","IN", "${this.listOrgaID.join(";")}"]]`);
    this.updateRequestParams();
    this.getData();
    this.isClearSelect = true;
  }
}
