import { Component, OnInit, Input, Output, EventEmitter, ViewChild, ElementRef } from '@angular/core';
import { ButtonColor } from '../../enum/common/button-color.enum';
import { ButtonType } from '../../enum/common/button-type.enum';
import { TagService } from 'src/app/services/tag/tag.service';
import { FormMode } from 'src/common/enum/form-mode.enum'
import { Tag } from '../../models/contact/Tag';
import { TransferDataService } from 'src/app/services/base/transfer-data.service';
import { AmisTranslationService } from 'src/common/services/amis-translation.service';
import { KeyCode } from 'src/common/enum/key-code.enum';
import { GroupConfig } from '../../models/group-config/group-config';
import { LayoutConfigService } from 'src/app/services/layout-config/layout-config.service';
import { BaseComponent } from 'src/common/components/base-component';
import { TypeControl } from '../../enum/common/type-control.enum';
import { FormatObjectUtils } from 'src/common/fn/format-object-ultils';
import { GroupFieldConfig } from '../../models/group-field-config/group-field-config';
import { AmisCommonUtils } from 'src/common/fn/common-utils';
import { EmployeeService } from 'src/app/services/employee/employee.service';
@Component({
  selector: 'contact-popup-group-config',
  templateUrl: './popup-group-config.component.html',
  styleUrls: ['./popup-group-config.component.scss']
})
export class PopupGroupConfigComponent extends BaseComponent implements OnInit {

  //#region  Properties

  @ViewChild("newTag", { static: false })
  tagInput: ElementRef
  @Input() visiblePopup: boolean;

  _formMode = FormMode.Insert;
  @Input() set formMode(val) {
    this._formMode = val;
    if (this._formMode === FormMode.Insert) {
      this.title = this.translateSV.getValueByKey('POPUP_GROUP_CONFIG_ADD_GROUP');
    }
    else {
      this.title = this.translateSV.getValueByKey('POPUP_GROUP_CONFIG_EDIT_GROUP');
    }
  };

  @Input() maxSortOrder = 0;

  // groupconfig nhóm thông tin
  _groupConfig: GroupConfig;
  _itemTreeBoxTag;
  @Input() set groupConfig(val) {
    this._groupConfig = AmisCommonUtils.cloneData(val);
    this.createValueData(val);
  }
  get groupConfig() {
    return this._groupConfig;
  };

  // dữ liệu sổ xuống của treeboxtag
  dataSource;

  _title = "";
  @Input() set title(value) {
    if (value !== this._title) {
      this._title = value;
    }
  };
  //Màu của button
  buttonColor = ButtonColor;
  //Loại butotn
  buttonType = ButtonType;

  invalidInput = false;

  emptyError = false;

  @Output() closed = new EventEmitter<boolean>();
  @Output() finnishWork = new EventEmitter<any>();
  @Input() isConfigDefault = false;
  //#endregion
  valueExprControlTree = "FieldName";
  displayExprControlTree = "Caption";
  constructor(
    private tranferSV: TransferDataService,
    private translateSV: AmisTranslationService,
    private layoutConfigSV: LayoutConfigService
  ) {
    super();
  }

  ngOnInit(): void {
    if (!this._groupConfig) {
      this._groupConfig = new GroupConfig();
      this._groupConfig.GroupConfigName = "";
    }

  }

  /**
   * Hàm hủy thêm
   * Created by: hgvinh 23/05/2020
   */
  cancel(value) {
    value.value = "";
    this.visiblePopup = false;
    this.closed.emit(false);
  }

  onClose() {
    this.visiblePopup = false;
    this.closed.emit(false);
  }

  onShown(input) {
    input.focus();
  }

  handleKeyUp(event) {
    if (event?.keyCode == KeyCode.Enter) {

    }
  }

  validateForm() {
    if (!this._groupConfig.GroupConfigName) {
      this.emptyError = true;
      return false;
    }
    return true;
  }

  /**
   * xử lý khi ấn lưu groupconfig
   */
  save() {
    if (!this.validateForm()) {
      return;
    }
    // lưu lại các thuộc tính của group đẩy lên
    this._groupConfig.GroupConfigID = this._groupConfig.GroupConfigID ? this._groupConfig.GroupConfigID : 0;
    this._groupConfig.GroupConfigName = this._groupConfig.GroupConfigName.trim();
    this._groupConfig.GroupConfigCode = this._groupConfig.GroupConfigCode ? this._groupConfig.GroupConfigCode : this._groupConfig.GroupConfigName.trim();
    this._groupConfig.AppCode = this._groupConfig.AppCode || EmployeeService.userInfo.UserOptions["ConnectAppCode"];

    if (this._formMode === FormMode.Update) {
      if (!this.isConfigDefault) {

        let listConfigDelete = this.listSelectedItem.filter(f => this._groupConfig.GroupFieldConfigs?.findIndex((x: any) => x[this.valueExprControlTree] === f[this.valueExprControlTree]) === -1
        ).map(x => {
          x.State = FormMode.Delete;
          x.IsLink = [TypeControl.Hyperlink, TypeControl.Email].includes(x.TypeControl) ? true : false;
          return x;
        });
        let listConfigInsert = this._groupConfig.GroupFieldConfigs?.filter((f: any) => this.listSelectedItem.findIndex((x: any) => x[this.valueExprControlTree] === f[this.valueExprControlTree]) === -1
        ).map((x, index) => {
          x.State = FormMode.Insert;
          x.IsLink = [TypeControl.Hyperlink, TypeControl.Email].includes(x.TypeControl) ? true : false;
          x.Row = index + 100;
          return x;
        });
        this._groupConfig.GroupFieldConfigs = listConfigDelete.concat(listConfigInsert);
      }
      else {
        this.finnishWork.emit(this._groupConfig);
        return;
      }
    } else if (this._formMode === FormMode.Insert) {
      if (this.isConfigDefault) {
        this.finnishWork.emit(this._groupConfig);
        return;
      }
      else {
        this._groupConfig.GroupFieldConfigs?.forEach((ele, i) => ele.Row = i + 1);
      }
    }

    this.layoutConfigSV.saveGroupConfig([this._groupConfig]).subscribe(res => {
      if (res?.Success && res.Data) {
        if (this._formMode === FormMode.Insert) {
          this.tranferSV.showSuccessToast(this.translateSV.getValueByKey("POPUP_GROUP_CONFIG_ADD_GROUP_SUCCESS"));
        }
        else {
          this.tranferSV.showSuccessToast(this.translateSV.getValueByKey("POPUP_GROUP_CONFIG_EDIT_GROUP_SUCCESS"));
        }
      } else {
        this.tranferSV.showErrorToast(this.translateSV.getValueByKey("ERROR_HAPPENED"));
      }
      this.onClose();
      this.finnishWork.emit();
    }, error => {
      this.tranferSV.showErrorToast(this.translateSV.getValueByKey("ERROR_HAPPENED"));
      this.onClose();
      this.finnishWork.emit();
    });
  }

  /**
   * khi control thay đổi value
   * @param dataChange 
   * @param typeControl 
   */
  controlValueChange(dataChange, typeControl) {
    switch (typeControl) {
      case TypeControl.DefaultType:
        if (dataChange?.target?.value) {
          // this._groupConfig.GroupConfigName = dataChange;
          this.emptyError = false;
        }
        break;
      case TypeControl.ComboTree:
        if (dataChange) {
          this._groupConfig.GroupFieldConfigs = dataChange;
        }
        break;
    }
  }

  listSelectedItem = [];
  listSelectedItemClone = [];

  /**
   * tạo giá trị bind vào control treetagbox
   * @param groupConfig 
   */
  createValueData(groupConfig) {
    if (groupConfig) {
      // this.formValue.FieldData.Value = groupConfig.GroupFieldConfigs.map(x => x.FieldName).join(';');
      // this.formValue.FieldData.DisplayValue = groupConfig.GroupFieldConfigs.map(x => x.Caption).join(';');
      let data = [];
      // data = [groupConfig].map(x => {
      //   return {
      //     FieldName: x.GroupConfigName,
      //     Caption: x.GroupConfigName,
      //     SortOrder: x.SortOrder,
      //     ParentID: null,
      //     selected: true
      //   }
      // });
      [groupConfig].forEach(g => {
        if (g.GroupFieldConfigs?.length) {
          g.GroupFieldConfigs.forEach(gf => {
            gf.ParentID = g.GroupConfigCode;
            gf.ParentName = g.GroupConfigName;
            gf.selected = true;
            data.push(gf);
          });
        }
      });
      this.listSelectedItem = data;
      this.listSelectedItemClone = AmisCommonUtils.cloneDataArray(data);
    }
  }


  loaddingControlTree;
  /**
   * khi control treetagbox mở
   */
  onTreeTagOpen() {

    this.loaddingControlTree = true;
    //gọi sv lấy groupconfig ở đây
    this.layoutConfigSV.getGroupConfigSource().subscribe(res => {
      if (res?.Success && res.Data) {
        this.dataSource = [];
        this.createTreeData(res.Data);
      }
    })
  }

  /**
   * tạo cây dữ liệu
   * @param listGroupConfig ds config
   * @param parentID id cha
   * @param parentName tên cha
   * dtnam1 6/10/2020
   */
  createTreeData(listGroupConfig, parentID?, parentName?) {
    // thêm config cha vào cây    
    
    let data = listGroupConfig.map(x => {
      let groupConfig: GroupConfig = {
        AppCode: x.AppCode,
        SortOrder: x.SortOrder
      }
      let data: any = {
        FieldName: x.GroupConfigSourceName,
        Caption: x.GroupConfigSourceName,
        TableName: x.TableName,
        ParentID: null
      };
      data = Object.assign(data, groupConfig);
      data[this.valueExprControlTree] = x.GroupConfigSourceCode;
      if (parentID) {
        data.ParentID = parentID;
        if (parentName) {
          data.ParentName = parentName;
        }
      }
      if (this.listSelectedItem.map(x => x.ParentID).includes(x.GroupConfigSourceName)) {
        data.selected = true;
        data.IsExpanded = true;
      }
      else {
        data.selected = false;
        data.IsExpanded = false; 
      }
      return data;
    });
    // data = data.filter(x => configCodeFilters.includes(x.FieldName));
    //thêm config con vào cây
    listGroupConfig.forEach(g => {
      if (g.GroupFieldConfigSources?.length 
        // && configCodeFilters.includes(g.GroupConfigSourceCode)
        ) {
        g.GroupFieldConfigSources = g.GroupFieldConfigSources.map(gf => {
          let fieldConfig: GroupFieldConfig = {
            AppCode: gf.AppCode,
            FieldName: gf.FieldName,
            DisplayField: gf.DisplayField,
            Caption: gf.Caption,
            DataType: gf.DataType,
            TypeControl: gf.TypeControl,
            Row: 0,
            EnumName: null
          }
          let data = {
            ParentID: g.GroupConfigSourceCode,
            ParentName: g.GroupConfigSourceName,
            selected: !!this.listSelectedItem.find(x => x.FieldName === gf.FieldName),
            GroupFieldConfigSourceID: gf.GroupFieldConfigSourceID,
            IsUse: gf.IsUse,
            TableName: gf.TableName,
          }
          data = Object.assign(data, fieldConfig);
          // data[this.valueExprControlTree] = g.GroupConfigCode + "_" + gf.FieldName;
          // data[this.valueExprControlTree] =  gf.FieldName;
          return data;
        })

        data.push(...g.GroupFieldConfigSources);
      }
      // nếu còn cấp nữa thì quay lại vòng lặp
      if (g.ListGroupConfigSourceChild?.length) {
        this.createTreeData(g.ListGroupConfigSourceChild, g.GroupConfigSourceCode, g.GroupConfigSourceName);
      }
    });
    this.dataSource.push(...data);
    // this.dataSource = this.dataSource.filter(x => x.IsUse !== false);
  }
}