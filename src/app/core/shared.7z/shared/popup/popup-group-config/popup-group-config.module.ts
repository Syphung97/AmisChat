import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PopupGroupConfigComponent } from './popup-group-config.component';
import { AmisPopupModule } from 'src/common/components/amis-popup/amis-popup.module';
import { AmisButtonModule } from 'src/common/components/amis-button/amis-button.module';
import { FormsModule } from '@angular/forms';
import { TranslateModule } from '@ngx-translate/core';
import { AmisControlTreeBoxTagModule } from 'src/common/components/amis-control-treeboxtag/amis-control-treeboxtag.module';

@NgModule({
  declarations: [PopupGroupConfigComponent],
  imports: [
    CommonModule,
    AmisButtonModule,
    AmisPopupModule,
    FormsModule,
    TranslateModule,
    AmisControlTreeBoxTagModule
  ],
  exports: [
    PopupGroupConfigComponent
  ]
})
export class PopupGroupConfigModule { }
