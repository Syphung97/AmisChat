export class DataQRCode {
  FullName: string;
  LastName: string;
  FirstName: string;
  OfficeTel: string;
  Mobile: string;
  Website: string;
  Organization: string;
  Email: string;
  Avatar: string;
  OfficeEmail: string;
  JobTitle: string;
}
