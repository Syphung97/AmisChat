import { BaseEntity } from 'src/common/models/base-entity';

export class TagUser extends BaseEntity {
  // PK
  TagUserID: number
  // PK
  TagID: number
  // Tên thẻ
  TagName: string
  // User ID đổi với thông tin lấy  từ hệ thống
  UserID: string
  // ID nhân viên lấy từ app hồ sơ nhân sự
  EmployeeID?: number
  // id liên hệ
  ContactID: number
  //
  OwnerID: string
  // Ngày sửa
  ModifiedDate?: Date
  // Người sửa
  ModifiedBy: string
}
