import { BaseEntity } from 'src/common/models/base-entity';

export class LayoutConfig extends BaseEntity {

    LayoutConfigID?: number;
    FieldName: string;
    Caption: string;
    RowIndex: number;
    ColumnIndex: number;
    IsAppEP: boolean;

    IsVisible?: boolean;
    IsDefault?: boolean;
    UserID?: string;
    DataType?: number;
    TenantID?: string;
    CreatedDate?: Date;
    ModifiedDate?: Date;
    ModifiedBy?: string;
    OldData?: string;
    PassWarningCode?: string
}
