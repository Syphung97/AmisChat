import { BaseEntity } from 'src/common/models/base-entity';
import { TagUser } from './TagUser';

export class Tag extends BaseEntity{

  TagID: number;

  TagName: string;

  TextColor?: string;

  TagColor?: string;

  OwnerID?: string;

  SortOrder?: number;

  ListTagUser?: Array<TagUser>;

}
