/**
* Model cho app để lưu lên server
 * @export
* @class EventForInsert
*/
export class App {
    // 
    AppID?: number
    // 
    AppCode?: string
    // 
    AppName?: string
    // class để binding icon logo
    ClassLogo?: string
    // Chú thích
    Discription?: string
    // Có phải app nội bộ ko
    IsInternalApp?: boolean
    //đang kết nối
    IsConnecting?: boolean
}
