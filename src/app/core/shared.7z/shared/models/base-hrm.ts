import { BaseEntity } from 'src/common/models/base-entity';
import { FieldConfig } from './field-config/field-config';

export class BaseHRMModel extends BaseEntity{
        /// <summary>
        /// Thông tin danh sách config
        /// </summary>
        FieldConfigs?: FieldConfig[] = [];


        /// <summary>
        /// Trường lưu giá trị mặc định
        /// </summary>
        CustomField?: string;
        /// <summary>
        /// Trường parse giá trị custom
        /// </summary>
        CustomFieldParse?: string;

        IsDelete?: boolean;

        ValidateMethod?: string[];

        FnsLoadData?: Function;

        DataSource?: any;

        IsErrorCustom?: boolean = false;

        ErrorMessage?: string = "";
}
