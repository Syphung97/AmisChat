import { BaseEntity } from 'src/common/models/base-entity';
import { GroupFieldConfig } from '../group-field-config/group-field-config';
import { LayoutGridConfig } from '../layout-grid-config/layout-grid-config';
/**
* Model cho group_config để lưu lên server
 * @export
* @class EventForInsert
*/
export class GroupConfig extends BaseEntity {
    // PK
    GroupConfigID?: number;
    // Tên nhóm
    GroupConfigName?: string;
    // Tên nhóm
    GroupConfigCode?: string;
    // AppCode
    AppCode?: string;
    // Thứ tự
    SortOrder?: Number;
    // có p hệ thống k
    IsSystem?: boolean;
    //ds groupfield
    GroupFieldConfigs?: GroupFieldConfig[];
}
