import { DataType } from 'src/common/models/export/data-type.enum';
import { TypeControl } from '../../enum/common/type-control.enum';
import { BaseEntity } from 'src/common/models/base-entity';

export class GroupFieldConfig extends BaseEntity {
    /// <summary>
    /// PK
    /// </summary>
    GroupFieldConfigID?: number;
    /// <summary>
    /// ID nhóm config
    /// </summary>
    GroupConfigID?: number;
    /// <summary>
    /// tên trường dùng để hiển thị
    /// </summary>
    Caption?: string;
    /// <summary>
    /// AppCode của app kết nối
    /// </summary>
    AppCode?: string;
    /// <summary>
    /// kiểu dữ liệu
    /// </summary>
    DataType?: number;
    /// <summary>
    /// ID nhóm config
    /// </summary>
    EnumName?: string;
    /// <summary>
    /// tên trường
    /// </summary>
    FieldName?: string;
    /// <summary>
    /// tên trường
    /// </summary>
    DisplayField?: string;
    /// <summary>
    /// loại control
    /// </summary>
    TypeControl?: TypeControl;
    /// <summary>
    /// có hiển thị dưới dạng đg link ko
    /// </summary>
    IsLink?: boolean;
    // có p hệ thống k
    IsSystem?: boolean;
    /// <summary>
    /// thứ tự hiển thị trong mục liên hệ
    /// </summary>
    Row?: Number;
    /// <summary>
    /// ID ng đăng nhập
    /// </summary>
    UserID?: string;
}