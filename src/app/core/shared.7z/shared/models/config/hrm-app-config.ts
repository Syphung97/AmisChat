import { AppConfig } from "src/common/models/app-config";

export class HRMAppConfig extends AppConfig {
    isCheckPermission: boolean;
    isConnectToHrm2: any;
    isAllowChangeConnect: boolean;
}
