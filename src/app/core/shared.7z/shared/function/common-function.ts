export function convertDateToString(date: Date) {
  let res = "";
  if (date) {
    res =  convertDayToString(date.getDate()) + "/" + convertMonthToString(date.getMonth()) + "/" +  date.getFullYear();
  }
  return res;
}
export function convertMonthToString(month: number) {
  let res = "";
  if (month <= 8) {
    res = "0" + (month + 1);
  }  else {
    res = (month + 1).toString();
  }
  return res;
}


export function convertDayToString(day: number) {
  let res = "";
  if (day <= 9) {
    res = "0" + day;
  } else {
    res = (day).toString();
  }
  return res;
}
