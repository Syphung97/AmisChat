
/**
 * xử lý CCTC
 */
export class HandleOrgUtils {
    /**
   * Lấy cơ cấu cha cấp 2
   * dtnam1 16/12/2020
   */
    static getSecondOrg(listOrganization, organizationUnitID, organizationUnitName) {
        if (!listOrganization || !listOrganization.length){
            return "";
        }
        let org = listOrganization.find(x => x.OrganizationUnitID === organizationUnitID);
        let orgParents = [];
        while (org?.ParentID) {
            let orgParent = listOrganization.find(x => x.OrganizationUnitID === org.ParentID);
            if (orgParent) {
                orgParents.unshift(orgParent);
            }
            org = orgParent;
        }
        return orgParents[1]?.OrganizationUnitName && organizationUnitName !== orgParents[1].OrganizationUnitName ? ` - ${orgParents[1].OrganizationUnitName}` : '';
    }
    
}
