export const PermissionCode = {
    NoPermission: "NoPermission", // không có quyền
    View: "View", // xem
    Modify: "Modify",
    DulicateData: "Dữ liệu trùng"
  };
  