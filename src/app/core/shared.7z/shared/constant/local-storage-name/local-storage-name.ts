export const LocalStorageKey = {
  Permission: "Permission",
  DataOrganizationUnit: 'DataOrganizationUnit',
  GridFieldConfig: 'GridFieldConfig'
}
