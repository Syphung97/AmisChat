/**
 * Enum các môi trường
 * created by vhtruong - 06/03/2020
 */
export const EnvironmentKey = {
  Prod: "prod",
  Dev: "dev",
  Local: "local"
};
