export const AppCode = {
    Contact: "Contact",
    Platform: "Platform",
    AMISHRM2: "AMISHRM2",
    EmployeesProfile: "EmployeesProfile"
}