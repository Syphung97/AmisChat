// Các tùy chọn của người dùng
export const OptionKey = {
  TemplateFliter: 'TemplateFliter'
};
