export const SubSystemCode = {
    Profile: "Profile",
    Contract: "Contract",
    Setting: "Setting",
    App: "App",
    ConnectionSetting: "ConnectionSetting"
  };
  