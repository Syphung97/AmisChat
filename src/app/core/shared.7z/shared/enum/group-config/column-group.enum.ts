
/**
 * Loại group là 1 cột hay 2 cột
 * @export
 * @enum {number}
 * created by vhtruong - 08/05/2020
 */
export enum ColumnGroup {
    OneCol = 1,
    TwoCol = 2
}