export enum UploadTypeEnum {
    //avtar
    Avatar = 40
}
