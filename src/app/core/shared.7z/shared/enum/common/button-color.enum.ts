export enum ButtonColor {
    BluePrimary = 1, // Button màu xanh đậm
    BlueSecondary = 2, // Button màu xanh nhạt
    RedPrimary = 3, // Button màu đỏ đậm
    RedSecondary = 4, // Button màu đỏ nhạt
    Normal = 5, // Button xám thường
    White = 6, //Button màu trắng
    Orange = 7, //Button màu vàng đậm
  }