
/**
 * Dạng hiển thị dự liệu danh sách
 * @export
 * @enum {number}
 * created by vhtruong - 04/05/2020
 */
export enum TypeView {
    Grid = 1,
    MasterDetail = 2
}
