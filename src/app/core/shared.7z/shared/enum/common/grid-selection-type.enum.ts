export enum GridSelectionType {
    Single = 1,
    Multi = 2
}