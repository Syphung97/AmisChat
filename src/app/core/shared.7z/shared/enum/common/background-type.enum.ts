export enum BackgroundType {
    White = 1, // nền trắng
    LightGrey = 2, // nền xám nhạt
    Grey = 3, // nền xám
  }