export enum ButtonType {
    OnlyText = 1, // Button chỉ có text
    OnlyIcon = 2, // Button chỉ có icon
    Link = 3, // Button chỉ có icon
  }