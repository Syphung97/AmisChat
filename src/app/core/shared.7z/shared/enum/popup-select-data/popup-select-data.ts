export enum PopupSelectData {
    Base = 1,
    JobPosition = 2,
    OrganizationUnit = 3
}