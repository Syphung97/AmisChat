export enum ExportOption {
  recent = 'Tất cả liên hệ',
  favourity = 'Liên hệ yêu thích'
}
