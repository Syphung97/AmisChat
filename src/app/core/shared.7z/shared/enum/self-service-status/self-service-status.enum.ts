export enum SelfServiceStatus {
    Wait = 1,
    Reject = 2
}