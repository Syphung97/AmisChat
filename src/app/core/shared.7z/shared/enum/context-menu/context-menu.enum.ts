
export enum ContextMenu {
    Edit = 'Edit', // sửa
    Delete = 'Delete', // Xóa
    DisActive = 'DisActive', // ngừng kích hoạt tài khoản
    NotifyNewsfeed = 'NotifyNewsfeed', // Thông báo mạng xã hội nội bộ
    EmployeeSelfUpdate = 'EmployeeSelfUpdate', // Nhân viên tự cập nhật
    MergeData = 'MergeData', // Trộn văn bản
    Print = 'Print', // In
    Export = 'Delete', // Xuất khẩu
    ExportExcel = 'ExportExcel', // Xuất khẩu Excel
    ExportPDF = 'ExportPDF', // Xuất khẩu PDF
    AdjustOrganization = 'AdjustOrganization', // Điều chuyển đơn vị công tác
    Import = 'Import', // Nhập khẩu
    UpdateFile = 'UpdateFile', // Cập nhật file
    UpdateFileMass = 'UpdateFileMass', // Cập nhật file hàng loạt
    AdvanceExport = 'AdvanceExport', // Cập nhật file hàng loạt
}
