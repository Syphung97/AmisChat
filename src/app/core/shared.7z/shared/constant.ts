export enum ActionType{
  View = 0,
  Add = 1,
  Update = 2,
  Delete = 3
}
export enum Gender{
  Male = 1,
  Female = 0
}
