import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { EmptyViewComponent } from './empty-view.component';
import { AmisButtonModule } from 'src/common/components/amis-button/amis-button.module';



@NgModule({
  declarations: [EmptyViewComponent],
  imports: [
    CommonModule,
    AmisButtonModule
  ],
  exports: [
    EmptyViewComponent
  ]
})
export class EmptyViewModule { }
