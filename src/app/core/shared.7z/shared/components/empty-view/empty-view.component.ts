import { Component, OnInit, Input, EventEmitter, Output } from '@angular/core';

@Component({
  selector: 'amis-empty-view',
  templateUrl: './empty-view.component.html',
  styleUrls: ['./empty-view.component.scss']
})
export class EmptyViewComponent implements OnInit {

  @Input() emptyStateIcon: string = "";
  @Input() emptyText: string = "";
  @Input() guideText: string = "";
  @Input() buttonName: string = "";
  @Output() onClickBtn: EventEmitter<any> = new EventEmitter<any>();

  constructor() { }

  ngOnInit(): void {
  }

  /**
   * Sự kiện click button
   */
  onClickButton(e){
    this.onClickBtn.emit(e);
  }
}
