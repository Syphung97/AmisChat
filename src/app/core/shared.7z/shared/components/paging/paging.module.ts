import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PagingComponent } from './paging.component';

import { DxSelectBoxModule } from 'devextreme-angular';
import { TranslateModule } from '@ngx-translate/core';

@NgModule({
  declarations: [PagingComponent],
  imports: [
    CommonModule,
    DxSelectBoxModule,
    TranslateModule
  ],
  exports: [
    PagingComponent
  ]
})
export class PagingModule { }
