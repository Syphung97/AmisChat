import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { EmployeeService } from 'src/app/services/employee/employee.service';
import { LayoutConfigService } from 'src/app/services/layout-config/layout-config.service';
import { TagUserService } from 'src/app/services/tag-user/tag-user.service';
import { TagService } from 'src/app/services/tag/tag.service';
import { TagUser } from 'src/app/shared/models/contact/TagUser';
import { FormMode } from 'src/common/enum/form-mode.enum';
import { DataType } from 'src/common/models/export/data-type.enum';
import { TransferDataService } from 'src/app/services/base/transfer-data.service';
import { AmisTranslationService } from 'src/common/services/amis-translation.service';
import { ActivatedRoute, Router } from '@angular/router';
import { convertDateToString } from 'src/app/shared/function/common-function';
import { AmisCommonUtils } from 'src/common/fn/common-utils';
import { ConfigService } from 'src/common/services/app-config.service';
import { AppConfig } from 'src/common/models/app-config';
import { DataQRCode } from 'src/app/shared/models/contact/data-qr-code';
declare var MISAQRCode: any;
@Component({
  selector: 'app-detail-contact',
  templateUrl: './detail-contact.component.html',
  styleUrls: ['./detail-contact.component.scss']
})
export class DetailContactComponent implements OnInit {

  //trường kiểm tra loading hay không
  isLoading: boolean = false;
  //object liên hệ
  _contactObject;

  @Input() set contactObject(value) {
    if (value !== this._contactObject) {
      this._contactObject = AmisCommonUtils.cloneData(value);

      this.getTagsOfUser();
      this.getGroupCongig();
      this.updateHistory();
      this.dataQRCode = this._contactObject.dataQRCode;
      this.generateQRCode();
    }
  }

  @Output() onCloseDetail = new EventEmitter<any>();

  @Output() reloadGrid = new EventEmitter<any>();

  @Output() onShareQRCode = new EventEmitter();

  datasConfig = []
  //tags của một user
  tagsOfUser = [];
  //tag chưa được gán cho user
  remainingTags = [];
  //trường hiển thị popover
  isVisibleOption = false;

  isVisibleAddTag = false;
  //trường hiển thị popup thêm nhãn
  visiblePopupAddTag = false;
  //danh sách người được thêm vào nhãn mới
  listSelectedContact = [];

  dataTypeIns = DataType;

  dataQRCode = new DataQRCode();

  constructor(
    private employeeSV: EmployeeService,
    private layoutConfigSV: LayoutConfigService,
    private tagUserSV: TagUserService,
    private tagSV: TagService,
    private transferSV: TransferDataService,
    private translateSV: AmisTranslationService,
    private activatedRoute: ActivatedRoute,
    private router: Router
  ) { }

  ngOnInit(): void {
    this.listOrganization = JSON.parse(sessionStorage.getItem('AMIS_Contact_Orgs')) || [];
  }



  handleShowingPopoverOption(event) {
    this.getRemainingTag();
  }
  /**
   * Hàm lấy nhãn của liên hệ
   * Created by: hgvinh 29/05/2020
   */
  getTagsOfUser() {
    let param = {
      ContactID: this._contactObject.ContactID
    };
    this.tagUserSV.getTagsByUserID(param).subscribe(data => {
      if (data?.Success) {
        if (data?.Data && data.Data?.length > 0) {
          this.tagsOfUser = data.Data;
        }
        else {
          this.tagsOfUser = [];
        }
      }
      // this.transferSV.reloadSidebar();
    })
  }
  /**
   * Hàm lấy các nhãn còn lại chưa được gán cho user hiện tại
   * created by: hgvinh 30/05/2020
   */
  getRemainingTag() {
    this.tagSV.getTagsByOwnerID().subscribe(data => {
      if (data?.Success) {
        if (data?.Data && data.Data?.length > 0) {
          let userTag = this.tagsOfUser.map(x => x.TagID);
          let remainingTags = data.Data.filter(
            function (e) {
              return this.indexOf(e.TagID) === -1;
            },
            userTag
          )
          this.remainingTags = remainingTags;
        }
      }
    })
  }
  /**
   * thêm tag cho liên hệ
   * created by: hgvinh 30/05/2020
   */
  addTagToUser(tag) {
    const tagUser = new TagUser();
    tagUser.TagID = tag.TagID;
    tagUser.TagName = tag.TagName;
    tagUser.ContactID = this._contactObject.ContactID;
    tagUser.State = FormMode.Insert;

    this.tagUserSV.save(tagUser).subscribe(data => {
      if (data?.Success) {
        this.transferSV.showSuccessToast(this.translateSV.getValueByKey("GRID_CONTACT_ADD_TO_TAG_SUCCESS"));
        let index = this.remainingTags.indexOf(tag)
        this.remainingTags.splice(index, 1);
        this.tagsOfUser.push(data?.Data);
        this.transferSV.reloadSidebar();
        if (this.activatedRoute.snapshot.queryParams?.TagID == tag.TagID) {
          this.reloadGrid.emit(true);
        }
      }
      else {
        this.transferSV.showErrorToast(this.translateSV.getValueByKey("GRID_CONTACT_ADD_TO_TAG_FAIL"));
      }
    },
      err => {
        this.transferSV.showErrorToast(this.translateSV.getValueByKey("COMMON_SYSTEM_ERROR"));
      });
  }

  /**
   * Hàm xóa bỏ nhãn khỏi user hiện tại
   * created by: hgvinh 30/05/2020
   */
  removeTagFromUser(tag) {
    this.tagUserSV.delete([tag]).subscribe(data => {
      if (data?.Success) {
        this.transferSV.showSuccessToast(this.translateSV.getValueByKey("DETAIL_CONTACT_DELETE_SUCCESS"));
        let index = this.tagsOfUser.indexOf(tag)
        this.tagsOfUser.splice(index, 1);
        this.remainingTags.push(tag);
        this.transferSV.reloadSidebar();
        if (this.activatedRoute.snapshot.queryParams?.TagID == tag.TagID) {
          this.reloadGrid.emit(true);
        }
      }
      else {
        this.transferSV.showErrorToast(this.translateSV.getValueByKey("DETAIL_CONTACT_DELETE_FAIL"));
      }
    },
      err => {
        this.transferSV.showErrorToast(this.translateSV.getValueByKey("COMMON_SYSTEM_ERROR"));
      });
  }
  /**
   * Hàm hiện popup thêm nhãn
   */
  openPopupAddTag() {
    this.listSelectedContact.push(this._contactObject);
    this.visiblePopupAddTag = true;
  }
  /**
   * Hàm đóng popup thêm nhãn
   */
  onClosePopupAddTag(event) {
    if (event) {
      this.getTagsOfUser();

    }
    this.visiblePopupAddTag = false;
  }

  /**
   * sắp xếp groupconfig
   * @param groupConfig
   * dtnam1 8/10/2020
   */
  sortGroupConfig(groupConfig) {
    groupConfig = groupConfig.sort((a, b) => a.SortOrder - b.SortOrder);
    groupConfig.forEach(ele => {
      ele.GroupFieldConfigs = ele.GroupFieldConfigs.sort((a, b) => a.Row - b.Row);
    })
  }

  /**
   * lấy groupconfig
   */
  getGroupCongig() {
    let isConnectAppEP = EmployeeService.userInfo.IsUseAppEP && EmployeeService.userInfo.TenantOptions["IsConnectToEPApp"];
    const groupConfig = JSON.parse(sessionStorage.getItem(`AMIS_Contact_GroupConfig${isConnectAppEP}`));

    if (groupConfig?.length > 0) {
      this.datasConfig = groupConfig;
      this.sortGroupConfig(this.datasConfig);
      this.processDisplayData();
    }
    else {

      this.isLoading = true;

      this.layoutConfigSV.getGroupConfig().subscribe(data => {
        if (data?.Success) {
          if (data?.Data && data.Data?.length > 0) {
            this.datasConfig = data.Data;
            sessionStorage.setItem(`AMIS_Contact_GroupConfig${isConnectAppEP}`, JSON.stringify(data.Data));
            this.sortGroupConfig(this.datasConfig);
            this.processDisplayData();
            setTimeout(() => {
              this.isLoading = false;
            }, 500);
          }
        }
      })
    }
  }

  /**
   * xử lý data trc khi hiển thị
   */
  processDisplayData() {
    this.datasConfig.forEach(el => {
      el.IsVisible = true;
      el.GroupFieldConfigs.forEach(field => {
        const fieldName = field.FieldName;
        if (this._contactObject[fieldName]) {
          el.IsVisible = true;

          if (field.DataType === DataType.CheckBoxType) {
            if (this._contactObject[fieldName] === 0) {
              this._contactObject[fieldName] = this.translateSV.getValueByKey("FEMALE");
            }
            if (this._contactObject[fieldName] === 1) {
              this._contactObject[fieldName] = this.translateSV.getValueByKey("MALE");
            }
          }
          // if (field.DataType === DataType.DateTimeType || field.DataType === DataType.DateType) {
          //   if (!!this._contactObject[fieldName]) {
          //     let dateValue = new Date(this._contactObject[fieldName + "Original"]);
          //     if (!(dateValue instanceof Date) || isNaN(dateValue.getTime())) {
          //       dateValue = new Date(this._contactObject[fieldName])
          //     }
          //     if (dateValue instanceof Date && !isNaN(dateValue.getTime())) {
          //       this._contactObject[fieldName] = convertDateToString(dateValue);
          //     }
          //   } else {
          //     this._contactObject[fieldName] = '';
          //   }
          // }
          const contact = this._contactObject;
          const key = contact[fieldName + 'Original'] ? fieldName + 'Original' : fieldName;

          // if (field.DataType == DataType.Email) { // xử lý email
          //   this._contactObject[fieldName] = contact[key] ? `<a href="mailto:${contact[key]}">${contact[key]} </a>` : "";
          // }
          // else if (field.DataType == DataType.Phone) { // xử lý SĐT
          //   this._contactObject[fieldName] = contact[key] ? `<a href="tel:+${contact[key]}">${contact[key]}</a>` : "";
          // }
        }
      })
    })
  }

  updateHistory() {
    // if (this._contactObject?.ContactID && this._contactObject?.EmployeeID) {
    const param = {
      ContactID: this._contactObject.ContactID
    }
    this.employeeSV.updateHistory(param).subscribe(data => {

    });
    // }
  }
  handleCloseDetail() {
    this.onCloseDetail.emit(false);
  }

  handleSelectFavorite(IsFavourite) {
    const param = {
      IsFavourite: true,
      ContactIDs: []
    }
    param.ContactIDs = [
      this._contactObject.ContactID
    ]
    if (IsFavourite) {
      this._contactObject.IsFavourite = true;
      this.transferSV.showSuccessToast(this.translateSV.getValueByKey("GRID_CONTACT_ADD_TO_FAVOURITE_DONE"))
    }
    else {
      this._contactObject.IsFavourite = false;
      param.IsFavourite = false;
      this.transferSV.showSuccessToast(this.translateSV.getValueByKey("GRID_CONTACT_REMOVE_TO_FAVOURITE_DONE"));
    }
    this.employeeSV.updateFavourite(param).subscribe(data => {
      if (this.activatedRoute.snapshot.component["name"] == "FavouriteContactComponent") {

        this.reloadGrid.emit(true);
      }
    });
  }

  shareContact(event) {
    const selBox = document.createElement('textarea');

    selBox.value = `${this._contactObject.FullName}\n${this._contactObject.JobPositionName ? this._contactObject.JobPositionName : ""} - ${this._contactObject.OrganizationUnitName ? this._contactObject.OrganizationUnitName : ""}\n`;
    this.datasConfig.forEach(groupConfig => {
      // if (groupConfig.IsVisible) {
      //   selBox.value += `\n${groupConfig.GroupConfigName}:\n`.toUpperCase();
      // }
      groupConfig.GroupFieldConfigs.forEach(element => {

        if (element.FieldName != 'Empty') {
          if (element.FieldName == 'Mobile' || element.FieldName == "OfficeEmail" || element.FieldName == "Skype" || element.FieldName == "OfficeTel" || element.FieldName == "Email" || element.FieldName == "Facebook") {
            if (this._contactObject[element.FieldName]) {

              selBox.value += `${element.Caption}: ${this._contactObject[element.FieldName + 'Original']}\n`;
            }
          }
          else if (this._contactObject[element.FieldName]) {
            selBox.value += `${element.Caption}: ${this._contactObject[element.FieldName]}\n`;
          }
        }
      })
    });

    document.body.appendChild(selBox);
    selBox.focus();
    selBox.select();
    document.execCommand('copy');
    document.body.removeChild(selBox);
    this.transferSV.showSuccessToast(this.translateSV.getValueByKey("COPY_DONE"));
  }

  pathOrganization: string;
  listOrganization = [];
  /**
   * Xây dựng đường dẫn CCTC
   * Created by ltanh1 17/06/2020
   */
  buildPathOrganization(OUName) {
    let OU = this.listOrganization.filter(function (et) {
      return et.OrganizationUnitName === OUName;
    });
    let pathOU = OUName;
    if (OU && OU.length > 0 && OU[0].ParentID) {
      while (OU[0].ParentID) {
        let parentOU = this.listOrganization.filter(function (et) {
          return et.OrganizationUnitID === OU[0].ParentID;
        });
        if (parentOU) {
          pathOU = parentOU[0].OrganizationUnitName + ' → ' + pathOU;
        }
        OU = parentOU;
      }
    }
    return pathOU;
  }

  /**
   * Xử lý hover lên cctc
   * Created by ltanh1 17/06/2020
   */
  handleHoverOrganization(value: string) {
    this.pathOrganization = this.buildPathOrganization(value);
  }

  /**
   * build link đến trang cá nhân ở newfeed
   * @param convertID
   */
  buildNewFeedLink(convertID) {
    let newFeedLink = (ConfigService.settings as AppConfig).profileNewFeed;
    newFeedLink = newFeedLink.replace('@ConvertID', convertID);
    window.open(newFeedLink, '_blank');
  }

  shareQRCode(): void {
    this.onShareQRCode.emit();
  }

  generateQRCode(): void {

    this._contactObject.QRCode = MISAQRCode.Client.createVCard(this.dataQRCode, 120, "svg");
  }

  /**
   * copyLinkQRCode
   *
   * @memberof PopupQrCodeComponent
   */
  copyLinkQRCode(): void {
    const el = MISAQRCode.Google.createVCard(this.dataQRCode, 240);
    const link = el.children[0].getAttribute("src");

    const selBox = document.createElement('textarea');
    selBox.value = link;
    document.body.appendChild(selBox);
    selBox.focus();
    selBox.select();
    document.execCommand('copy');
    document.body.removeChild(selBox);
    this.transferSV.showSuccessToast(this.translateSV.getValueByKey("COPY_DONE"));
  }

  /**
   * downloadQRCode
   *
   * @memberof PopupQrCodeComponent
   */
  downloadQRCode(): void {
    const svg = MISAQRCode.Client.createVCard(this.dataQRCode, 120, "svg");
    MISAQRCode.Fn.downloadSVG(svg, this._contactObject.FullName);

    const canvas = MISAQRCode.Client.createVCard(this.dataQRCode, 120, "canvas");
    MISAQRCode.Fn.downloadPNG(canvas, this._contactObject.FullName);
  }

  log(e) {
    console.log(e);
  }
}
