import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { GridContactComponent } from './grid-contact.component';
import { TranslateModule } from "@ngx-translate/core";
import {
  DxDropDownBoxModule,
  DxTreeViewModule, DxPopoverModule, DxScrollViewModule
} from 'devextreme-angular';
import { AmisNoSanitizeModule } from 'src/common/pipes/amis-no-sanitize/amis-no-santinize.module';
import { DetailContactComponent } from './detail-contact/detail-contact.component';
import { PagingModule } from '../paging/paging.module';
import { PopupAddTagModule } from '../../popup/popup-add-tag/popup-add-tag.module';
import { PopupEmailSelectionModule } from '../../popup/popup-email-selection/popup-email-selection.module';
import { PopupExportModule } from '../../popup/popup-export/popup-export.module';
import { EmptyViewModule } from '../empty-view/empty-view.module';
import { PopupAddTagUserModule } from '../../popup/popup-add-tag-user/popup-add-tag-user.module';
import { PopupSelectDataModule } from '../../popup/popup-select-data/popup-select-data.module';
import { AMISDateModule } from 'src/common/pipes/amis-date/amis-date.module';
import { AmisLoadingContactModule } from 'src/common/components/amis-loading-contact/amis-loading-contact.module';
// import { PopupQrCodeModule } from '../../popup/popup-qr-code/popup-qr-code.module';
import { AmisIconModule } from 'src/common/components/amis-icon/amis-icon.module';
import { AmisEncodeHtmlModule } from 'src/common/pipes/amis-encode-html/amis-encode-html.module';
import { DataPipeModule } from '../../pipe/data-pipe/data-pipe.module';

@NgModule({
  declarations: [GridContactComponent, DetailContactComponent],
  imports: [
    CommonModule,
    TranslateModule,
    DxDropDownBoxModule,
    DxTreeViewModule,
    AmisNoSanitizeModule,
    PagingModule,
    DxPopoverModule,
    DxScrollViewModule,
    PopupAddTagModule,
    PopupEmailSelectionModule,
    PopupExportModule,
    EmptyViewModule,
    PopupAddTagUserModule,
    PopupSelectDataModule,
    AMISDateModule,
    AmisLoadingContactModule,
    // PopupQrCodeModule,
    AmisIconModule,
    AmisEncodeHtmlModule,
    DataPipeModule
  ],
  exports: [
    GridContactComponent
  ]
})
export class GridContactModule { }
