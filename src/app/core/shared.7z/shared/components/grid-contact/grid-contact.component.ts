import {
  Component,
  OnInit,
  Input,
  ViewChild,
  ElementRef,
  HostListener,
} from "@angular/core";
import { DxDropDownBoxComponent } from "devextreme-angular";
import { AmisTranslationService } from "src/common/services/amis-translation.service";
import { CommonAnimation } from "src/common/animation/common-animation";
import { EmployeeService } from "src/app/services/employee/employee.service";
import { ActivatedRoute, Router } from "@angular/router";
import { convertDateToString } from "../../function/common-function";
import { TransferDataService } from "src/app/services/base/transfer-data.service";
import { TagService } from "src/app/services/tag/tag.service";
import { TagUser } from "../../models/contact/TagUser";
import { Tag } from "../../models/contact/Tag";
import { TagUserService } from "src/app/services/tag-user/tag-user.service";
import { OrganizationUnitService } from "src/app/services/organizaion-unit/organization-unit.service";
import { FormMode } from "src/common/enum/form-mode.enum";
import { AvatarService } from "src/app/services/user/avatar.service";
import { AmisCommonUtils } from "src/common/fn/common-utils";
import { TypeTabContact } from "src/common/enum/type-tab-contact.enum";
import { DataType } from "src/common/models/export/data-type.enum";
import { AmisTransferDataService } from "src/common/services/amis-transfer-data.service";
import { LayoutConfigService } from "src/app/services/layout-config/layout-config.service";
import { ExportService } from "src/app/services/export/export.service";
import { FileTypeEnum } from "src/common/models/export/file-type.enum";
import { ExportData } from "src/common/models/export/export-data";
import { ColumnHeaderConfig } from "src/common/models/export/column-header-config";
import { AlignmentType } from "src/common/models/export/alignment-type.enum";
import { DownloadService } from "src/app/services/download/download.service";
import { ExportOption } from "../../enum/export-option/export-option.enum";
import { KeyCode } from "src/common/enum/key-code.enum";
import { BaseComponent } from "src/common/components/base-component";
import { ConfigService } from "src/common/services/app-config.service";
import { AppConfig } from "src/common/models/app-config";
import { HandleOrgUtils } from "../../function/handle-org-utils";
import { DataQRCode } from "../../models/contact/data-qr-code";
import { UserOptionService } from "src/app/services/user-option/user-option.service";
import { UserService } from "src/app/services/user/user.service";

declare var MISAQRCode: any;
declare var $: any;
@Component({
  selector: "app-grid-contact",
  templateUrl: "./grid-contact.component.html",
  styleUrls: ["./grid-contact.component.scss"],
  animations: [CommonAnimation.slideToLeft, CommonAnimation.slideToggleLeft],
})
export class GridContactComponent extends BaseComponent implements OnInit {
  _title = "";
  _searchValue = "";
  _pageIndex = 1;
  _pageSide = 50;
  _filterQuery = "";
  paramRequest = {
    PageIndex: this._pageIndex,
    PageSize: this._pageSide,
    Filter: "",
    QuickSearch: {
      Columns: ["FullName", "EmployeeCode", "Mobile", "Email"],
      SearchValue: "",
    },
    CustomParam: {
      OrganizationUnitID: this.currentUserInfo.OrganizationUnitID,
    },
    Sort: window.btoa(
      `[{"selector":"LastName","desc":"false"}, {"selector":"FirstName","desc":"false"}]`
    ),
  };
  // Vị trí avatar
  targetAvatar: any;

  //Avatar hiển thị
  avatarDisplay: string;
  tagsOfUser = [];

  @Input() set title(data) {
    if (data !== this._title) {
      this._title = data;
    }
  }

  // tslint:disable-next-line:ban-types
  @Input() CallAPI: Function;

  _customeData;
  @Input() set CustomeData(data) {
    this._customeData = data;
  }

  @Input() TypeContact: TypeTabContact;

  //trường xác định xem có phải click vào tag không
  @Input() isTagClick: boolean;

  @ViewChild("dropdown", { static: false })
  dropdown: DxDropDownBoxComponent;

  @ViewChild("scrollContent", { static: false })
  scrollContent: ElementRef;

  //trường kiểm tra xem có phải tìm kiếm hay không
  isSearch: boolean = false;

  isExistSelectedItemInDataSource = false;
  quantitySelectedContact = 0;
  datasConfig = [];

  dataSource = [];

  treeBoxValueOrga: string[] = [];
  listOrganization = [];

  listOrgaID: string[];

  totalRecord;
  tags: any = [];

  tagUsers: Array<TagUser> = [];
  //#region Display Detail
  isVisiblePopupDetail = false;

  //trường hiển thị popup thêm liên hệ
  visiblePopupAddData: boolean = false;

  //trường hiển thị popover avatar
  visiblePopoverAvatar: boolean = false;

  //trường hiển thị popup thêm nhãn
  visiblePopupAddTag: boolean = false;

  //trường hiển thị popup gửi email
  visiblePopupSendEmail: boolean = false;

  //trường hiển thị popup xuất khẩu
  visiblePopupExport: boolean = false;

  // Hiển thị popup quét QR code
  visiblePopupQRCode = false;

  valueDetailSelected = {};

  isVisiblePopover = false;

  isVisibleOption = false;
  targetPopoverOption;

  isLoading = true;
  listSelectedContact;
  isFilterByOrg = false;
  isShowDetail: boolean = false;

  userChooseID: any;
  contactID: any;

  pathOrganization: string;
  searchUserID;
  listFieldConfig = [
    {
      Caption: this.translateSV.getValueByKey("FullName"),
      FieldName: "FullName",
      CurrentValue: this.translateSV.getValueByKey("FullName"),
      RowIndex: 1,
      ColumnIndex: 1,
      ListOption: [this.translateSV.getValueByKey("FullName")],
      OrganizationUnitName: this.translateSV.getValueByKey("FullName"),
    },
    {
      Caption: this.translateSV.getValueByKey("EmployeeCode"),
      FieldName: "EmployeeCode",
      CurrentValue: this.translateSV.getValueByKey("EmployeeCode"),
      RowIndex: 1,
      ColumnIndex: 2,
      ListOption: [this.translateSV.getValueByKey("EmployeeCode")],
      OrganizationUnitName: this.translateSV.getValueByKey("EmployeeCode"),
    },
    {
      Caption: this.translateSV.getValueByKey("JobPositionName"),
      FieldName: "JobPositionName",
      CurrentValue: this.translateSV.getValueByKey("JobPositionName"),
      RowIndex: 2,
      ColumnIndex: 1,
      ListOption: [this.translateSV.getValueByKey("JobPositionName")],
      OrganizationUnitName: this.translateSV.getValueByKey("JobPositionName"),
    },
    {
      Caption: this.translateSV.getValueByKey("OrganizationUnitName"),
      FieldName: "OrganizationUnitName",
      CurrentValue: this.translateSV.getValueByKey("OrganizationUnitName"),
      RowIndex: 2,
      ColumnIndex: 2,
      ListOption: [this.translateSV.getValueByKey("OrganizationUnitName")],
      OrganizationUnitName: this.translateSV.getValueByKey(
        "OrganizationUnitName"
      ),
    },
  ];

  //#endregion
  selectedInfo = [];
  listExportCategory = [
    {
      OrganizationUnitID: ExportOption.recent,
      OrganizationUnitName: ExportOption.recent,
    },
    {
      OrganizationUnitID: ExportOption.favourity,
      OrganizationUnitName: ExportOption.favourity,
    },
  ];
  currentExportCategory;
  listChooseRecord = [];

  paramSearchs: any = [];

  constructor(
    private translateSV: AmisTranslationService,
    private employeeSV: EmployeeService,
    private userAvatarSV: AvatarService,
    private activatedRoute: ActivatedRoute,
    private tranferSV: TransferDataService,
    private amisTranferDataSV: AmisTransferDataService,
    private tagSV: TagService,
    private tagUserSV: TagUserService,
    private layoutConfigSV: LayoutConfigService,
    private organizationUnitSV: OrganizationUnitService,
    private exportSV: ExportService,
    private downloadService: DownloadService,
    private router: Router
  ) {
    super();
  }

  ngOnInit(): void {
    if (this.router.url.includes("favorite-contact")) {
      this.isTagClick = true;
    }

    this.getAllOrganization();
    this.activatedRoute.queryParams.subscribe((value) => {
      // tslint:disable-next-line:no-string-literal
      if (value["searchvalue"]) {
        this._searchValue = value.searchvalue;
        this._pageIndex = 1;
        if (UserOptionService.searchOption) {
          this.updateRequestParams(UserOptionService.searchOption);
        } else {
          this.updateRequestParams();
        }
        this.isSearch = true;
        this.isShowDetail = value.showDetail;
      } else if (value["userID"]) {
        this.searchUserID = value["userID"];
        this.updateRequestParams();
      } else {
        this._searchValue = "";
        this._pageIndex = 1;
        this.updateRequestParams();
        this.isSearch = false;
      }
    });

    // let listLayoutConfig = JSON.parse(sessionStorage.getItem("AMIS_Contact_ConfigLayoutGrid"));

    // this.getConfigColumn();

    // this.getAllTag();
  }

  /**
   * Cập nhập param gọi server
   *
   * @memberof GridContactComponent
   */
  updateRequestParams(filter?) {
    this.paramRequest.PageIndex = this._pageIndex;
    this.paramRequest.PageSize = this._pageSide;

    this.paramRequest.QuickSearch.SearchValue = this._searchValue;

    this.paramRequest.Filter = "";

    this.paramRequest.Sort = window.btoa(
      `[{"selector":"LastName","desc":"false"},{"selector":"FirstName","desc":"false"}]`
    );
    this.getLayoutConfig();
  }

  firstTimeOpenOrg = true;
  /**
   * Mở thanh cctc
   * dtnam1 12/10/2020
   */
  onOpenOrg() {
    if (this.firstTimeOpenOrg) {
      // this.treeBoxValueOrga = [];
      // this.getAllOrganization();
      this.firstTimeOpenOrg = false;
    }
  }

  /**
   * Lấy cơ cấu tổ chức công ty
   */
  getAllOrganization() {
    const orgs = JSON.parse(sessionStorage.getItem("AMIS_Contact_Orgs"));
    if (!orgs || orgs?.length == 0) {
      this.organizationUnitSV.getAllOrganizationByUser().subscribe((res) => {
        if (res?.Success && res.Data) {
          sessionStorage.setItem("AMIS_Contact_Orgs", JSON.stringify(res.Data));
          this.listOrganization = this.buildTreeDataListOrganizaiton(res.Data);
        }
      });
    } else {
      this.listOrganization = this.buildTreeDataListOrganizaiton(orgs);
    }
  }

  /**
   * hàm build danh sách dữ liệu sử dụng cho cây cơ cấu tổ chức
   * @param {any} data
   * @memberof RecruitmentListComponent
   * dtnam1 06/0/2020
   */
  buildTreeDataListOrganizaiton(listData) {
    if (listData && listData.length > 0) {
      const listAllParent = this.findAllParent(listData);
      if (listAllParent && listAllParent.length > 0) {
        const parentID = listAllParent[0].OrganizationUnitID;
        this.treeBoxValueOrga.push(parentID);
        listAllParent.forEach((el) => {
          const temp = listData.find((x) => x.MISACode === el.MISACode);
          if (temp) {
            temp.ParentID = null;
          }
        });
      }
    }
    return listData;
  }

  /**
   * Tìm tất cả các node tổng
   * dtnam1 06/0/2020
   * @param listData : misaCode của đơn vị bất kỳ
   */
  findAllParent(listData) {
    const listParent = [];
    listData.forEach((item) => {
      if (item.MISACode && item.MISACode.length > 8) {
        const listCode = item.MISACode.split("/");
        listCode.splice(listCode.length - 2, 1);
        const miCoParent = listCode.join("/");
        const itemPar = listData.find((x) => x.MISACode === miCoParent);
        if (!itemPar) {
          item.IsExpanded = true;
          listParent.push(item);
        }
      } else {
        item.IsExpanded = true;
        listParent.push(item);
      }
    });
    return listParent;
  }
  syncTreeViewSelection($event) {}

  /**
   * Lấy danh sách trường tìm kiếm
   * nmduy 16/12/2020
   */
  getSearchFieldByLayoutAndUserOption() {
    let optionSearchs = EmployeeService.userInfo?.UserOptions?.SearchOption;

    if (optionSearchs?.length) {
      // nếu có lưu lựa chọn ng dùng
      this.paramSearchs = optionSearchs
        .filter((x) => x.isSelected)
        ?.map((x) => x.Caption);
      this.paramRequest.QuickSearch.Columns = optionSearchs
        .filter((x) => x.isSelected && x.FieldName != "Empty")
        .map((x) => x.FieldName);
    } else {
      // không thì lấy theo layout config
      this.paramSearchs = this.datasConfig.map((item) => item.Caption);
      this.paramRequest.QuickSearch.Columns = this.datasConfig
        .filter((x) => x.FieldName != "Empty")
        .map((item) => item.FieldName);
    }

    this.getContactData();
  }

  /**
   * hàm chọn key tree cơ cấu phòng ban
   *
   * @param {any} e
   * @memberof RecruitmentListComponent
   * dtnam1 01/06/2020
   */
  treeView_itemSelectionChanged(e) {
    if (e && e.event) {
      const orgID = e.itemData.OrganizationUnitID;
      // tslint:disable-next-line:no-string-literal
      this.paramRequest.CustomParam["OrganizationUnitID"] = orgID;

      this._pageIndex = 1;
      this.updateRequestParams();
      // const nodes = e.component.getNodes();
      this.dropdown.instance.close();
      this.treeBoxValueOrga = e.itemData.OrganizationUnitID;

      // const misaCodeSelect = e.itemData.MISACode;
      // const listOrgaSelect = this.listOrganization.filter(item => {
      //   return item.MISACode.startsWith(misaCodeSelect) === true;
      // });
      // this.listOrgaID = [];
      // if (listOrgaSelect && listOrgaSelect.length > 0) {
      //   listOrgaSelect.forEach(item => {
      //     this.listOrgaID.push(item.OrganizationUnitID);
      //   });
      // }
      if (
        this.listOrganization[0].OrganizationUnitID == this.treeBoxValueOrga
      ) {
        this.isFilterByOrg = false;
      } else {
        this.isFilterByOrg = true;
      }
    }
    // this.buildFilterSubmit();
  }

  // /**
  //    * build cấu điều kiện lọc trên thanh công cụ
  //    *
  //    * @memberof HrmProfileToolbarComponent
  //    * dtnam1 01/06/2020
  //    */
  // buildFilterSubmit() {
  //   const filterParam = {
  //     ListOrganizationUnitID: this.listOrgaID
  //   };
  //   this._filterQuery = AmisCommonUtils.Base64Encode(`[["OrganizationUnitID","IN", "${this.listOrgaID.join(";")}"]]`);

  // }

  /**
   * Lấy thông tin layout
   * nmduy 16/12/2020
   */
  getLayoutConfig() {
    this.datasConfig = JSON.parse(
      sessionStorage.getItem(`AMIS_Contact_LayoutConfig`)
    );
    if (!this.datasConfig) {
      this.layoutConfigSV.getConfigLayoutGrid().subscribe((res) => {
        if (res?.Success && res.Data) {
          res.Data.forEach((x) => {
            if (x.DisplayField) {
              x.FieldName = x.DisplayField;
            }
          });
          this.datasConfig = res.Data;
          sessionStorage.setItem(
            "AMIS_Contact_LayoutConfig",
            JSON.stringify(res.Data)
          );
          this.tranferSV.newLayoutConfig();
          this.getSearchFieldByLayoutAndUserOption();
        }
      });
    } else {
      this.getSearchFieldByLayoutAndUserOption();
    }
  }

  /**
   * Lấy danh sách liên hệ
   * nmduy 16/12/2020
   */
  getContactData() {
    this.isLoading = true;
    this.amisTranferDataSV.showLoading("");
    this.dataSource = [];

    // cập nhật trường thanh search
    let columns = this.paramRequest?.QuickSearch?.Columns;
    if (columns?.includes("Address") || columns?.includes("Gender")) {
      this.paramRequest.QuickSearch.Columns = columns.map((ele) => {
        if (ele === "Address") {
          ele = "CurrentAddress";
        }
        if (ele === "Gender") {
          ele = "GenderName";
        }
        return ele;
      });
    }
    if (this.searchUserID) {
      this.getUserByUserID();
    } else {
      this.CallAPI(this.paramRequest, this._customeData).subscribe(
        (data) => {
          this.isLoading = false;
          if (data?.Success) {
            if (data?.Data?.PageData) {
              this.dataSource = data.Data.PageData;
              setTimeout(() => {
                this.scrollContent.nativeElement.scrollTo(0, 0);
              }, 50);
            }
            if (data.Data?.Total) {
              this.totalRecord = data.Data.Total;
            }
            this.handleData();
          }
        },
        (err) => {
          this.amisTranferDataSV.hideLoading();
        }
      );
    }
  }

  /**
   * Lấy thông tin người dùng theo userid
   * nmduy 31/05/2021
   */
  getUserByUserID() {
    this.employeeSV.getUserData(this.searchUserID).subscribe(
      (res) => {
        this.isLoading = false;
        this.searchUserID = null;
        if (res?.Success && res?.Data?.PageData) {
          this.dataSource = [res.Data.PageData];
          this.totalRecord = 1;
          this.isShowDetail = true;
          this.handleData();
        }
      },
      (err) => {
        this.amisTranferDataSV.hideLoading();
      }
    );
  }

  /**
   * Xử lý config và data sau khi lấy
   * dtnam1 12/10/2020
   */
  handleData() {
    this.amisTranferDataSV.hideLoading();
    this.selectedInfo = this.datasConfig;
    this.selectedInfo.forEach((e) => {
      e.OrganizationUnitName = e.Caption;
    });
    this.processData();
  }

  /**
   * Xử lí dữ liệu binding sau khi lấy
   *
   * @memberof GridContactComponent
   */
  processData() {
    console.log("process-data");

    const tmpDataSorce = this.dataSource;

    tmpDataSorce.forEach((el) => {
      // xử lý CCTC
      // el.OrganizationUnitDisplay = el.OrganizationUnitName ? `(${ el.OrganizationUnitName }${ this.getSecondOrg(el.OrganizationUnitID, el.OrganizationUnitName) })` : '';
      // el.OrganizationUnitDisplay = el.OrganizationUnitName ? el.OrganizationUnitName + HandleOrgUtils.getSecondOrg(this.listOrganization, el.OrganizationUnitID, el.OrganizationUnitName) : '';
      el.OrganizationUnitDisplay = this.buildPathOrganization(
        el.OrganizationUnitID
      );
      Object.keys(el).forEach((x) => {
        el[x] = this.encodeHTML(el[x]);
      });
      // bỏ những config trùng
      let configs = this.datasConfig.filter(
        (x, i, self) => self.findIndex((f) => f.FieldName === x.FieldName) === i
      );

      configs.forEach((cf) => {
        el[`${cf.FieldName}Original`] = el[`${cf.FieldName}`];
        if (
          cf.DataType == DataType.DateTimeType ||
          cf.DataType == DataType.DateType
        ) {
          // xử lý ngày tháng
          if (!!el[`${cf.FieldName}`]) {
            const dateValue = new Date(el[`${cf.FieldName}`]);
            if (dateValue instanceof Date && !isNaN(dateValue.getTime())) {
              el[`${cf.FieldName}Original`] = convertDateToString(dateValue);
            } else {
              el[`${cf.FieldName}Original`] = "";
            }
          } else {
            el[`${cf.FieldName}Original`] = "";
          }
        }
      //   // else if (cf.DataType == DataType.CheckBoxType) { // xử lý giới tính
      //   //   if (el[`${cf.FieldName}`] == 0) {
      //   //     el[`${cf.FieldName}`] = this.translateSV.getValueByKey("FEMALE");
      //   //   }
      //   //   if (el[`${cf.FieldName}`] == 1) {
      //   //     el[`${cf.FieldName}`] = this.translateSV.getValueByKey("MALE");
      //   //   }
      //   // }
      //   // thêm title
      //   el[`${cf.FieldName}TitleHTML`] = el[`${cf.FieldName}`];

      //   if (cf.DataType == DataType.Email) {
      //     // xử lý email
      //     el[cf.FieldName] = el[cf.FieldName]
      //       ? `<a href="mailto:${el[cf.FieldName]}">${el[cf.FieldName]} </a>`
      //       : "";
      //   } else if (cf.DataType == DataType.Phone) {
      //     // xử lý SĐT
      //     el[cf.FieldName] = el[cf.FieldName]
      //       ? `<a href="tel:+${el[cf.FieldName]}">${el[cf.FieldName]}</a>`
      //       : "";
      //   }
      });

      let words = el.CurrentAddress?.split(" ");
      words = words?.filter((word) => {
        return word.replace("\\", ",");
      });
      el.CurrentAddress = el.CurrentAddress
        ? `<a href="https://www.google.com/maps/search/${words.join(
            "+"
          )}"  target="_blank">${el.CurrentAddress}</a>`
        : "";

      // el.SkypeIDTitleHTML = el.Skype;
      if (!!el.Skype) {
        el.Skype = el.Skype.includes("skype:")
          ? `<a href="${el.Skype}" target="_blank">${el.Skype} </a>`
          : `<a href="skype:${el.Skype}" target="_blank">${el.Skype} </a>`;
      } else {
        el.Skype = "";
      }

      // el.FacebookIDTitleHTML = el.Facebook;
      el.Facebook = this.handleFacebook(el.Facebook);

      el.Avatar = this.userAvatarSV.getAvatar(el.ConvertID);

      this.createQRCode(el);
      // el.BirthDay = el.BirthDay ? convertDateToString(new Date(el.BirthDay)) : "";
      el.IsHover = false;
      el.IsFocus = false;
      el.IsSelected = false;
    });

    this.dataSource = tmpDataSorce;

    if (this.dataSource.length && this.isShowDetail) {
      this.handleFocusCard(this.dataSource[0]);
    }
    this.datasConfig = this.datasConfig?.filter((el) => el.RowIndex >= 3);
  }

  /**
   * xử lý link facebook
   * @param facebook
   */
  handleFacebook(facebook) {
    if (facebook) {
      if (!facebook.includes("https://")) {
        return `<a href="https://${facebook}" target="_blank">${facebook} </a>`;
      }
      if (!facebook.includes("facebook.com")) {
        const facebooklink = facebook.trim().toLocaleLowerCase();
        let paramFa = facebooklink.split("facebook.com");
        let faceID = "";
        if (paramFa.length > 1) {
          faceID = paramFa[1];
          faceID = faceID.replace("/", "");
        } else {
          paramFa = facebooklink.split("fb.com");
          if (paramFa.length > 1) {
            faceID = paramFa[1];
            faceID = faceID.replace("/", "");
          } else {
            faceID = paramFa[0];
          }
        }
        return `<a href="https://facebook.com/${faceID}" target="_blank">${facebook} </a>`;
      }
      return `<a href="${facebook}" target="_blank">${facebook} </a>`;
    }
    return "";
  }

  //#region  Khối xử lý hsự kiện

  /**
   * Xử lí khi hover vào 1 card trên grid
   *
   * @param {any} item
   * @param {any} i
   * @param {any} IsHover
   * @memberof GridContactComponent
   */
  handleHoverCard(item, i, IsHover) {
    this.dataSource.forEach((e) => {
      e.IsHover = false;
    });
    if (IsHover) {
      this.dataSource.forEach((e) => {
        e.IsHover = false;
      });
      const currentItem = this.dataSource[i];
      if (!currentItem.IsSelected) {
        this.dataSource[i].IsHover = true;
      }
    }
  }

  /**
   * Xử lí select 1 card
   *
   * @param {any} item
   * @param {any} i
   * @param {any} IsSelected
   * @memberof GridContactComponent
   */
  handleSelectCart(item, i, IsSelected, event) {
    event.stopPropagation();
    if (IsSelected) {
      this.dataSource[i].IsSelected = true;
    } else {
      this.dataSource[i].IsSelected = false;
    }

    this.checkExistSelectedItemInDataSource();
  }

  /**
   * Xử lí toggle yêu thích
   *
   * @param {any} item
   * @param {any} i
   * @param {any} IsFavourite
   * @memberof GridContactComponent
   */
  handleSelectFavorite(item, i, IsFavourite, event) {
    event.stopPropagation();
    const param = {
      IsFavourite: true,
      ContactIDs: [],
    };
    param.ContactIDs.push(item.ContactID);
    if (IsFavourite) {
      this.dataSource[i].IsFavourite = true;
    } else {
      this.dataSource[i].IsFavourite = false;
      param.IsFavourite = false;
    }
    this.employeeSV.updateFavourite(param).subscribe((data) => {
      if (data?.Success) {
        if (this.router.url.includes("favorite-contact")) {
          this.dataSource.splice(i, 1);
        }
        if (IsFavourite) {
          this.tranferSV.showSuccessToast(
            this.translateSV.getValueByKey("GRID_CONTACT_ADD_TO_FAVOURITE_DONE")
          );
        } else {
          this.tranferSV.showSuccessToast(
            this.translateSV.getValueByKey(
              "GRID_CONTACT_REMOVE_TO_FAVOURITE_DONE"
            )
          );
        }
      } else {
        this.tranferSV.showErrorToast(
          this.translateSV.getValueByKey("GRID_CONTACT_ADD_TO_FAVOURITE_FAIL")
        );
      }
    });
  }

  /**
   * Xử lí sư kiện đóng popup detail
   *
   * @param {any} event
   * @memberof GridContactComponent
   */
  handleOnClosePopupDetail(event) {
    this.isVisiblePopupDetail = false;
    this.dataSource.forEach((e) => {
      e.IsFocus = false;
    });
  }

  getAllTag() {
    this.tagSV.getTagsByOwnerID().subscribe((data) => {
      if (data?.Success) {
        this.listExportCategory = [
          {
            OrganizationUnitID: ExportOption.recent,
            OrganizationUnitName: ExportOption.recent,
          },
          {
            OrganizationUnitID: ExportOption.favourity,
            OrganizationUnitName: ExportOption.favourity,
          },
        ];
        data.Data.forEach((element) => {
          this.listExportCategory.push({
            OrganizationUnitID: element.TagID,
            OrganizationUnitName: element.TagName,
          });
        });

        this.currentExportCategory = this.listExportCategory[0];
      }
    });
  }

  /**
   * lấy dữ liệu tag hiển thị ở nút ba chấm
   * @param event
   * @param afterAddTag có p hàm gọi sau khi thêm tag mới k
   */
  handleOnShownTagOver(event, afterAddTag = false) {
    let allTag = JSON.parse(sessionStorage.getItem("AMIS_Contact_AllTag"));
    if (allTag) {
      this.handleTagData(allTag, afterAddTag);
    } else {
      this.tagSV.getTagsByOwnerID().subscribe((data) => {
        if (data?.Success) {
          sessionStorage.setItem(
            "AMIS_Contact_AllTag",
            JSON.stringify(data.Data)
          );
          this.handleTagData(data.Data, afterAddTag);
        }
      });
    }
  }

  handleTagData(tagData, afterAddTag) {
    let userTag = this.tagsOfUser.map((x) => x.TagID);
    let remainingTags = tagData.filter(function (e) {
      return this.indexOf(e.TagID) === -1;
    }, userTag);
    if (!afterAddTag) {
      this.tags = remainingTags;
    } else {
      this.tranferSV.reloadSidebar();
    }
  }

  /**
   * Xử lí sự kiện thay đổi paging
   *
   * @param {any} event
   * @memberof GridContactComponent
   */
  handleOnPagingChanged(event) {
    this._pageIndex = event?.PAGE_INDEX;
    this._pageSide = event?.PAGE_SIZE;
    this.updateRequestParams();
    window.scrollTo(0, 0);
  }

  /**
   * hiện popover avatar
   * created by hgvinh - 26/05/2020
   *
   * @param {any} event
   * @memberof GridContactComponent
   */
  mouseseenterAvatar(event, contact) {
    this.targetAvatar = event.target;
    this.visiblePopoverAvatar = true;
    this.avatarDisplay = this.userAvatarSV.getAvatar(
      contact.ConvertID,
      450,
      450
    );
  }

  /**
   *
   * ẩn popover avatar
   * created by hgvinh - 26/05/2020
   *
   * @memberof GridContactComponent
   */
  mouseLeaveAvatar() {
    this.visiblePopoverAvatar = false;
  }

  opendPopover() {
    this.isVisiblePopover = !this.isVisiblePopover;
  }

  /**
   * Hiện popup thêm nhãn mới
   * created by: hgvinh - 26/05/2020
   */
  addTag(type) {
    if (type == 1) {
      this.visiblePopupAddTag = true;
      this.listSelectedContact = this.dataSource.filter((e) => e.IsSelected);
    } else {
      this.visiblePopupAddTag = true;
      this.listSelectedContact = this.dataSource.filter((e) => e.IsFocus);
    }
  }

  /**
   * Đóng popup
   *
   * @param {any} event
   * @memberof SidebarComponent
   */
  onClosePopupAddTag(event) {
    if (event) {
      this.tagsOfUser = [];
      // this.tagSV.getTagsByOwnerID().subscribe(data => {
      //   if (data?.Success) {
      //     let userTag = this.tagsOfUser.map(x => x.TagID);
      //     let remainingTags = data.Data.filter(
      //       function (e) {
      //         return this.indexOf(e.TagID) === -1;
      //       },
      //       userTag
      //     )
      //     // this.tags = remainingTags;
      //   }
      // })
      this.handleOnShownTagOver(null, true);
    }
    this.visiblePopupAddTag = false;
  }
  /**
   * Ẩn popup gửi email
   * created by: hgvinh - 26/05/2020
   */
  closePopupSendEmail() {
    this.visiblePopupSendEmail = false;
  }

  /**
   * Ẩn popup gửi xuất khẩu
   * created by: hgvinh - 26/05/2020
   */
  closeExport() {
    this.visiblePopupExport = false;
  }

  sendEmail() {
    this.visiblePopupSendEmail = true;
  }

  exportContact() {
    this.visiblePopupExport = true;
    this.getConfigColumn();
    this.getAllTag();
  }
  //#endregion

  /**
   * Kiểm tra có tồn tại item đang đươch check hay không
   *
   * @memberof GridContactComponent
   */
  checkExistSelectedItemInDataSource() {
    let check = this.dataSource.filter((e) => e.IsSelected);
    this.quantitySelectedContact = check.length;
    this.isExistSelectedItemInDataSource = check.length > 0 ? true : false;
  }

  /**
   * Chọn tất cả
   *
   * @memberof GridContactComponent
   */
  selectAll() {
    this.dataSource.forEach((e) => (e.IsSelected = true));
    this.checkExistSelectedItemInDataSource();
  }

  /**
   * Bỏ chọn tất cả
   *
   * @memberof GridContactComponent
   */
  unSelectAll() {
    this.dataSource.forEach((e) => (e.IsSelected = false));
    this.checkExistSelectedItemInDataSource();
  }

  /**
   * Thêm vào yêu thích
   *
   * @memberof GridContactComponent
   */
  addToFavorite() {
    const param = {
      IsFavourite: true,
      ContactIDs: [],
    };
    this.dataSource.forEach((e) => {
      if (e.IsSelected) {
        e.IsFavourite = true;
        param.ContactIDs.push(e.ContactID);
      }
    });
    this.employeeSV.updateFavourite(param).subscribe(
      (data) => {
        if (data?.Success) {
          this.tranferSV.showSuccessToast(
            this.translateSV.getValueByKey("GRID_CONTACT_ADD_TO_FAVOURITE_DONE")
          );
        } else {
          this.tranferSV.showErrorToast(
            this.translateSV.getValueByKey("GRID_CONTACT_ADD_TO_FAVOURITE_FAIL")
          );
        }
      },
      (err) => {
        this.tranferSV.showErrorToast(
          this.translateSV.getValueByKey("COMMON_SYSTEM_ERROR")
        );
      }
    );
  }

  /**
   * Găn thẻ cho user
   *
   * @param {any} item
   * @memberof GridContactComponent
   * CREATED: PTSY
   */
  addTagUser(item: Tag, type) {
    const tagID = item.TagID;
    const tagName = item.TagName;
    this.tagUsers = [];
    if (type == 1) {
      this.dataSource.forEach((el) => {
        if (el.IsSelected) {
          const tagUser = new TagUser();
          tagUser.TagID = tagID;
          tagUser.TagName = tagName;
          tagUser.ContactID = el.ContactID;
          tagUser.State = FormMode.Insert;
          this.tagUsers.push(tagUser);
        }
      });
    } else {
      this.dataSource.forEach((el) => {
        if (el.IsFocus) {
          const tagUser = new TagUser();
          tagUser.TagID = tagID;
          tagUser.TagName = tagName;
          tagUser.ContactID = el.ContactID;
          tagUser.State = FormMode.Insert;
          this.tagUsers.push(tagUser);
        }
      });
    }
    this.tagUserSV.saveList(this.tagUsers).subscribe(
      (data) => {
        if (data?.Success) {
          this.tagsOfUser = [];
          this.tranferSV.showSuccessToast(
            this.translateSV.getValueByKey("GRID_CONTACT_ADD_TO_TAG_SUCCESS")
          );
          this.isVisiblePopover = false;
          this.tranferSV.reloadSidebar();
        } else {
          this.tranferSV.showErrorToast(
            this.translateSV.getValueByKey("GRID_CONTACT_ADD_TO_TAG_FAIL")
          );
        }
      },
      (err) => {
        this.tranferSV.showErrorToast(
          this.translateSV.getValueByKey("COMMON_SYSTEM_ERROR")
        );
      }
    );
    this.isVisibleOption = false;
  }

  onSelectContact(e) {
    if (this.router.url.includes("favorite-contact")) {
      this.addFavourite(e);
      return;
    }
    this.addContactToTag(e);
  }

  /**
   * thêm liên hệ yêu thích
   * @param e
   */
  addFavourite(e) {
    const param = {
      IsFavourite: true,
      ContactIDs: e?.map((x) => x.ContactID),
    };
    this.employeeSV.updateFavourite(param).subscribe(
      (data) => {
        if (data?.Success) {
          this.tranferSV.showSuccessToast(
            this.translateSV.getValueByKey("GRID_CONTACT_ADD_TO_FAVOURITE_DONE")
          );
          this.getContactData();
        } else {
          this.tranferSV.showErrorToast(
            this.translateSV.getValueByKey("GRID_CONTACT_ADD_TO_FAVOURITE_FAIL")
          );
        }
      },
      (err) => {
        this.tranferSV.showErrorToast(
          this.translateSV.getValueByKey("COMMON_SYSTEM_ERROR")
        );
      }
    );
  }

  /**
   * hàm thêm liên hệ vào tag
   * created by: hgvinh 02/06/2020
   */
  addContactToTag(e) {
    let tagID = this._customeData.TagID;
    let tagName = this._customeData.TagName;
    e.forEach((el) => {
      const tagUser = new TagUser();
      tagUser.TagID = tagID;
      tagUser.TagName = tagName;
      tagUser.ContactID = el.ContactID;
      tagUser.State = FormMode.Insert;
      this.tagUsers.push(tagUser);
    });
    this.tagUserSV.saveList(this.tagUsers).subscribe(
      (data) => {
        if (data?.Success) {
          this.tranferSV.showSuccessToast(
            this.translateSV.getValueByKey("GRID_CONTACT_ADD_TO_TAG_SUCCESS")
          );
          this.getContactData();
          this.tranferSV.reloadSidebar();
        } else {
          this.tranferSV.showErrorToast(
            this.translateSV.getValueByKey("GRID_CONTACT_ADD_TO_TAG_FAIL")
          );
        }
      },
      (err) => {
        this.tranferSV.showErrorToast(
          this.translateSV.getValueByKey("COMMON_SYSTEM_ERROR")
        );
      }
    );
  }

  /**
   * Hàm lấy tag theo người dùng
   * Created by ltanh1 17/06/2020
   */
  getTagsOfUser() {
    let param = {
      ContactID: this.contactID,
    };
    if (
      !this.tagsOfUser ||
      !this.tagsOfUser.length ||
      this.tagsOfUser[0].EmployeeID !== this.contactID
    ) {
      this.tagUserSV.getTagsByUserID(param).subscribe((data) => {
        if (data?.Success) {
          if (data?.Data && data.Data?.length > 0) {
            this.tagsOfUser = data.Data;
          } else {
            this.tagsOfUser = [];
          }
        }
      });
    }
  }

  /**
   * Xử lí sự kiện click vào nút 3 chấm option
   *
   * @param {any} item
   * @param {any} i
   * @param {any} event
   * @memberof GridContactComponent
   */
  handleSelectOption(item, i, event) {
    if (item && item.ConvertID) {
      this.userChooseID = item.ConvertID;
    }
    if (item && item.EmployeeID) {
      this.contactID = item.ContactID;
    }

    this.getTagsOfUser();
    event.stopPropagation();
    this.dataSource.forEach((e) => {
      e.IsFocus = false;
    });
    item.IsFocus = true;

    if (this.targetPopoverOption == event.target) {
      this.isVisibleOption = !this.isVisibleOption;
    } else {
      setTimeout(() => {
        this.isVisibleOption = true;
      }, 200);
    }
    this.targetPopoverOption = "#" + event.target.id;
  }

  handleFocusCard(item, i?, bol?) {
    this.valueDetailSelected = item;
    const listSelectedContact = this.dataSource.filter((e) => e.IsSelected);
    if (listSelectedContact && listSelectedContact.length > 0) {
      if (item.IsSelected) {
        item.IsSelected = false;
        this.quantitySelectedContact--;
        if (listSelectedContact.length === 1) {
          this.isExistSelectedItemInDataSource = false;
        }
      } else {
        this.quantitySelectedContact++;
        item.IsSelected = true;
      }
      this.isVisiblePopupDetail = false;
    } else {
      this.dataSource.forEach((e) => {
        e.IsFocus = false;
      });
      item.IsFocus = true;
      // this.router.navigate([], {
      //   queryParams: {
      //     showDetail: 'true'
      //   },
      //   queryParamsHandling: 'merge'
      // });
      this.isVisiblePopupDetail = true;
    }
  }

  /**
   * Xây dựng đường dẫn CCTC
   * Created by ltanh1 17/06/2020
   */
  buildPathOrganization(OUID) {
    let OU = this.listOrganization.find(
      (item) => item.OrganizationUnitID == OUID
    );
    let pathOU = "";
    if (OU) {
      pathOU = OU.OrganizationUnitName;
      if (OU && OU.ParentID) {
        while (OU.ParentID) {
          let parentOU = this.listOrganization.find(
            (item) => item.OrganizationUnitID == OU.ParentID
          );
          if (parentOU && parentOU.ParentID) {
            pathOU = parentOU.OrganizationUnitName + " → " + pathOU;
          }
          if (parentOU.OrganizationUnitID) {
            OU = parentOU;
          }
        }
      }
    }
    return pathOU;
  }

  /**
   * Xử lý hover lên cctc
   * Created by ltanh1 17/06/2020
   */
  handleHoverOrganization(value: string) {
    this.pathOrganization = this.buildPathOrganization(value);
  }

  /**
   * Xử lý xóa các bản ghi được chọn khỏi thẻ
   * Created by ltanh1 30/06/2020
   */
  removeSelectedTag() {
    let param = [];
    let selectedContact = this.dataSource.filter((e) => e.IsSelected);
    selectedContact.forEach((e) => {
      param.push({
        TagID: this._customeData.TagID,
        ContactID: e.ContactID,
      });
    });
    this.tagUserSV.deleteTagUser(param).subscribe((res) => {
      if (res && res.Success) {
        this.getContactData();
        sessionStorage.removeItem("AMIS_Contact_AllTag");
        this.tranferSV.reloadSidebar();
        this.isExistSelectedItemInDataSource = false;
      }
    });
  }

  /**
   * Lấy data từ cache
   */
  getContactDataFromCache() {
    // let isConnectAppEP = EmployeeService.userInfo.IsUseAppEP && EmployeeService.userInfo.TenantOptions["IsConnectToEPApp"];
    let listFieldConfig = JSON.parse(
      sessionStorage.getItem(`AMIS_Contact_GroupConfig`)
    );
    let listFieldName;
    if (listFieldConfig.length) {
      listFieldName = this.listFieldConfig.map((e) => e.FieldName);
    }
    listFieldConfig.forEach((e) => {
      e.GroupFieldConfigs.forEach((element) => {
        element.OrganizationUnitName = element.Caption;
        if (listFieldName.indexOf(element.FieldName) === -1)
          this.listFieldConfig.push(element);
      });
    });
    // this.selectedInfo = JSON.parse(sessionStorage.getItem("AMIS_Contact_ConfigLayoutGrid"));
    // this.selectedInfo.forEach(e => {
    //   e.OrganizationUnitName = e.CurrentValue;
    // });
  }

  /**
   * Cache lại data vào sessionStorage
   */
  cacheData(key, data) {
    sessionStorage.setItem(key, JSON.stringify(data));
  }

  /**
   * Lấy thông tin các cột để xuất khẩu
   * Created by ltanh1 02/07/2020
   */
  getConfigColumn() {
    // let configLayoutGrid = sessionStorage.getItem("AMIS_Contact_ConfigLayoutGrid");
    // let isConnectAppEP = EmployeeService.userInfo.IsUseAppEP && EmployeeService.userInfo.TenantOptions["IsConnectToEPApp"];
    let groupConfig = sessionStorage.getItem(`AMIS_Contact_GroupConfig`);
    if (!groupConfig) {
      this.layoutConfigSV.getGroupConfig().subscribe((data) => {
        if (data?.Success) {
          if (data.Data) {
            let listFieldConfig = data.Data;
            let listFieldName;
            if (listFieldConfig.length) {
              listFieldName = this.listFieldConfig.map((e) => e.FieldName);
            }
            listFieldConfig.forEach((e) => {
              e.GroupFieldConfigs.forEach((element) => {
                element.OrganizationUnitName = element.Caption;
                if (listFieldName.indexOf(element.FieldName) === -1)
                  this.listFieldConfig.push(element);
              });
            });
            this.cacheData(`AMIS_Contact_GroupConfig`, data.Data);
          }
        }
      });

      // this.layoutConfigSV.getGroupFieldConfig().subscribe(data => {
      //   if (data?.Success && data.Data?.length > 0) {
      //     this.selectedInfo = data.Data;
      //     this.selectedInfo.forEach(e => {
      //       e.OrganizationUnitName = e.Caption;
      //     });
      //     this.cacheData('AMIS_Contact_ConfigLayoutGrid', this.selectedInfo);
      //   }
      // });
    } else {
      this.getContactDataFromCache();
    }
  }

  /**
   * Hàm xử lý xuất khẩu danh bạ
   * Created by ltanh1 02/07/2020
   */
  handleExportContact(e) {
    let param;
    if (e && e.selectData && e.selectData.length > 0) {
      if (e.tagID && e.tagID.OrganizationUnitID) {
        param = this.buildParamExport(
          FileTypeEnum.Excel,
          e.selectData,
          e.isByTag,
          e.tagID.OrganizationUnitID
        );
      } else {
        param = this.buildParamExport(FileTypeEnum.Excel, e.selectData);
      }

      this.exportSV.exportListEmployee(param).subscribe((res) => {
        if (res?.Success && res?.Data) {
          window.open(this.downloadService.downloadFile(res.Data), "_blank");
        } else {
          this.tranferSV.showErrorToast(
            this.translateSV.getValueByKey("ERROR_HAPPENED")
          );
        }
      });
    } else {
      this.tranferSV.showErrorToast(
        this.translateSV.getValueByKey("ERROR_HAPPENED")
      );
    }
  }

  /**
   * Hàm xây dựng param để xuất khẩu
   * Created by ltanh1 24/06/2020
   */
  buildParamExport(
    fileTypeExport: FileTypeEnum,
    columns,
    isByTag = false,
    tagID?
  ) {
    let pagingParam = this.buildPagingParam(columns, isByTag);
    let param: ExportData = new ExportData();
    let headerColumnList: ColumnHeaderConfig[] = [];

    columns.forEach((element) => {
      switch (element.DataType) {
        case DataType.NumberType:
          headerColumnList.push(
            new ColumnHeaderConfig(
              element.Caption,
              element.FieldName,
              DataType.NumberType,
              AlignmentType.Right
            )
          );
          break;
        case DataType.CurrencyType:
          headerColumnList.push(
            new ColumnHeaderConfig(
              element.Caption,
              element.FieldName,
              DataType.CurrencyType,
              AlignmentType.Right
            )
          );
          break;
        case DataType.PercentType:
          headerColumnList.push(
            new ColumnHeaderConfig(
              element.Caption,
              element.FieldName,
              DataType.NumberType,
              AlignmentType.Right
            )
          );
          break;
        case DataType.DateType:
          headerColumnList.push(
            new ColumnHeaderConfig(
              element.Caption,
              element.FieldName,
              DataType.DateType,
              AlignmentType.Right
            )
          );
          break;
        case DataType.DateTimeType:
          headerColumnList.push(
            new ColumnHeaderConfig(
              element.Caption,
              element.FieldName,
              DataType.DateTimeType,
              AlignmentType.Right
            )
          );
          break;
        default:
          headerColumnList.push(
            new ColumnHeaderConfig(
              element.Caption,
              element.FieldName,
              DataType.DefaultType,
              AlignmentType.Left
            )
          );
      }
    });

    const currentDate: Date = new Date();
    param.Title = "Danh sách liên hệ";
    param.ExportFileType = fileTypeExport;
    param.HeaderColumns = headerColumnList;
    param.FileName =
      "Danh_sach_lien_he_" +
      currentDate.getDate() +
      "." +
      (currentDate.getMonth() + 1) +
      "." +
      currentDate.getFullYear();
    if (isByTag) {
      if (tagID === ExportOption.recent) {
        param.APIPath = `Employee/data/`;
      } else if (tagID === ExportOption.favourity) {
        param.APIPath = `Employee/data-favourite`;
      } else {
        param.APIPath = `Employee/getbytag/${tagID}`;
      }
    } else {
      param.APIPath = "Employee/data/";
    }
    param.Param = pagingParam;
    param.IsAutoFitColumn = true;
    return param;
  }

  /**
   * Xây dựng tham số lấy dữ liệu xuất khẩu
   * Created by ltanh1 25/06/2020
   */
  buildPagingParam(columns, isByTag) {
    let pagingParam = this.paramRequest;

    this.listChooseRecord = this.dataSource.filter((e) => e.IsSelected);
    // let employeeIDs = "";
    let ContactIDs = "";
    if (this.listChooseRecord?.length) {
      for (let i = 0; i < this.listChooseRecord.length; i++) {
        const element = this.listChooseRecord[i];
        // employeeIDs += element.EmployeeID;
        ContactIDs += element.ContactID;
        if (i < this.listChooseRecord.length - 1) {
          // employeeIDs += ";";
          ContactIDs += ";";
        }
      }
    }

    pagingParam.QuickSearch.Columns = [];
    columns.forEach((e) => {
      pagingParam.QuickSearch.Columns.push(e.FieldName);
    });
    if (pagingParam.QuickSearch.SearchValue) {
      pagingParam.QuickSearch.SearchValue = "";
    }
    pagingParam["Filter"] = "";
    if (!isByTag) {
      pagingParam["Filter"] = AmisCommonUtils.Base64Encode(
        `["ContactID", "IN", "${ContactIDs}"]`
      );
    } else {
      pagingParam.PageSize = this.totalRecord;
    }

    return pagingParam;
  }

  /**
   * Copy contact
   *
   * @param {any} item
   * @param {any} i
   * @param {any} event
   * @memberof GridContactComponent
   */
  shareContact(item, i, event) {
    event.stopPropagation();
    const selBox = document.createElement("textarea");

    selBox.value = `${item.FullName}\n${
      item.JobPositionName ? item.JobPositionName : ""
    } - ${item.OrganizationUnitName ? item.OrganizationUnitName : ""}\n`;
    this.datasConfig.forEach((element) => {
      if (element.FieldName != "Empty") {
        // if (element.FieldName == 'Mobile' || element.FieldName == "OfficeEmail" || element.FieldName == "Skype" || element.FieldName == "OfficeTel" || element.FieldName == "Email" || element.FieldName == "Facebook") {
        if (item[element.FieldName]) {
          selBox.value += `${element.Caption}: ${
            item[element.FieldName + "Original"]
          }\n`;
        }
        // }
        // else if (item[element.FieldName]) {
        //   selBox.value += `${element.Caption}: ${item[element.FieldName]}\n`;
        // }
      }
    });

    document.body.appendChild(selBox);
    selBox.focus();
    selBox.select();
    document.execCommand("copy");
    document.body.removeChild(selBox);
    this.tranferSV.showSuccessToast(
      this.translateSV.getValueByKey("COPY_DONE")
    );
  }
  /**
   * cop dữ liệu 1 trường thông tin
   * nmduy 15/12/2020
   * @param item
   * @param config
   * @param e
   */
  copyField(item, config, e) {
    e.stopPropagation();
    if (
      config.DataType == DataType.DateType ||
      config.DataType == DataType.DateTimeType ||
      config.DataType == DataType.CheckBoxType
    ) {
      var value = item[config.FieldName];
    } else {
      var value = item[config.FieldName + "Original"];
    }
    this.copyData(value);
  }

  /**
   * copy trường tên-mã, và vị trí cv - đơn vị công tác
   * nmduy 15/12/2020
   */
  copyNamenCode(item, e) {
    e.stopPropagation();
    var value = `${item.FullName}`;
    if (item.EmployeeCode) {
      value = `${value} - ${item.EmployeeCode}`;
    }
    this.copyData(value);
  }

  /**
   * copy tên vị trí, đơn vị công tác
   * nmduy 15/12/2020
   */
  copyJobPositionnOrg(item, e) {
    e.stopPropagation();
    var value = "";
    if (item.JobPositionName) {
      value = `${item.JobPositionName}`;
    }
    if (item.OrganizationUnitName) {
      value = value
        ? `${value} - ${item.OrganizationUnitName}`
        : item.OrganizationUnitName;
    }
    this.copyData(value);
  }

  /**
   * Sao chép dữ liệu 1 trường
   * nmduy 15/12/2020
   */
  copyData(value) {
    const selBox = document.createElement("textarea");
    selBox.value = value;
    document.body.appendChild(selBox);
    selBox.focus();
    selBox.select();
    document.execCommand("copy");
    document.body.removeChild(selBox);
    this.tranferSV.showSuccessToast(
      this.translateSV.getValueByKey("COPY_DONE")
    );
  }

  dragEvent(e) {}

  // Phím tắt
  @HostListener("document:keyup", ["$event"])
  onKeyUp(event: KeyboardEvent) {
    switch (event.keyCode) {
      case KeyCode.F4:
        event.preventDefault();
        $("#input-search").focus();
        break;
      case KeyCode.Esc:
        event.preventDefault();
        this.isVisiblePopupDetail = false;
        // clear focus
        this.dataSource.forEach((e) => {
          e.IsFocus = false;
        });
        break;
    }
  }

  /**
   * build link đến trang cá nhân ở newfeed
   * @param convertID
   * dtnam1 17/12/2020
   */
  buildNewFeedLink(event, convertID) {
    event.stopPropagation();
    let newFeedLink = (ConfigService.settings as AppConfig).profileNewFeed;
    newFeedLink = newFeedLink.replace("@ConvertID", convertID);
    window.open(newFeedLink, "_blank");
  }

  /**
   * Bật PopupQrCode
   * @param item
   * @param i
   * @param event
   * Created :PTSY
   */
  shareQRCode(item, i, event): void {
    event?.stopPropagation();
    // this.valueDetailSelected = item;
    // this.visiblePopupQRCode = true;

    MISAQRCode.UI.Resource = {
      CopyLink: "Copy link",
      DownloadSVG: "Download SVG",
      DownloadPNG: "Download PNG",
      Clipboard: "coppied to clipboard",
      Description: "Scan to add to your contacts",
    };

    const res = {
      CopyLink: this.translateSV.getValueByKey("QRCODE_COPY_LINK"),
      DownloadSVG: this.translateSV.getValueByKey("QRCODE_DOWNLOAD_SVG"),
      DownloadPNG: this.translateSV.getValueByKey("QRCODE_DOWNLOAD_PNG"),
      Clipboard: this.translateSV.getValueByKey("QRCODE_CLIPBOARD"),
      Description: this.translateSV.getValueByKey("QRCODE_DESCRIPTION"),
    };

    MISAQRCode.UI.showVcard(item.dataQRCode, res);
  }

  /**
   * Tạo mã QR
   *
   * @param {any} el
   * @memberof GridContactComponent
   */
  createQRCode(el): void {
    const data = new DataQRCode();
    data.FullName = el.FullName;
    data.LastName = el.LastName;
    data.FirstName = el.FirstName;
    data.Mobile = el.MobileOriginal;
    data.OfficeTel = el.OfficeTelOriginal;
    // data.Organization = el.OrganizationOriginal;
    data.Organization = EmployeeService.userInfo.TenantName;
    data.Website = el.WebsiteOriginal;
    data.Email = el.EmailOriginal;
    data.Avatar = el.Avatar;
    data.JobTitle = el.JobPositionName;
    data.OfficeEmail = el.OfficeEmailOriginal;

    el.dataQRCode = data;
  }

  encodeHTML(data): void {
    // let t = data.content.content;
    if (typeof data == "string") {
      data = data.replace(/(?:\r\n|\r|\n)/g, "<br>");
      return data;
    }
    const txt = document.createElement("textarea");
    txt.innerHTML = data;
    data = txt.innerHTML;
    return data;
  }
}
