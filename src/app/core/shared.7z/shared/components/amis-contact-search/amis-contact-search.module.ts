import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AmisContactSearchComponent } from './amis-contact-search.component';
import { AmisButtonModule } from 'src/common/components/amis-button/amis-button.module';
import { DxPopoverModule } from 'devextreme-angular';
import { TranslateModule } from '@ngx-translate/core';
// import { AmisControlGroupModule } from 'src/common/components/amis-control-group/amis-control-group.module';


@NgModule({
  declarations: [AmisContactSearchComponent],
  imports: [
    CommonModule,
    DxPopoverModule,
    TranslateModule,
    AmisButtonModule,
    // AmisControlGroupModule,
  ],
  exports: [
    AmisContactSearchComponent
  ]
})
export class AmisContactSearchModule { }
