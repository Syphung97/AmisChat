import { Component, OnInit, ViewChild, ElementRef } from "@angular/core";
import { Router, NavigationStart, ActivatedRoute } from "@angular/router";
import { KeyCode } from "src/common/enum/key-code.enum";
import { TransferDataService } from "src/app/services/base/transfer-data.service";
import { CommonAnimation } from "src/common/animation/common-animation";
import { AmisTranslationService } from "src/common/services/amis-translation.service";
import { AmisStringUtils } from "src/common/fn/string-utils";
import { UserOptionService } from "src/app/services/user-option/user-option.service";
import { AmisTransferDataService } from "src/common/services/amis-transfer-data.service";
import { EmployeeService } from "src/app/services/employee/employee.service";
import { takeUntil } from "rxjs/operators";
import { BaseComponent } from "src/common/components/base-component";

@Component({
  selector: "app-amis-contact-search",
  templateUrl: "./amis-contact-search.component.html",
  styleUrls: ["./amis-contact-search.component.scss"],
  animations: [
    CommonAnimation.slideToggleLeft,
    CommonAnimation.fadeInOutHorizontal,
  ],
})
export class AmisContactSearchComponent
  extends BaseComponent
  implements OnInit {
  //#region Properties
  //viewchild content scroll
  @ViewChild("scrollContent") scrollContent: ElementRef;

  isFocused: boolean = false;

  isShown: boolean = false;

  showHistory = false;

  isDefault = false;

  showSearchByOption = false;

  listSearchHistory = [];

  filter;

  searchOption: string;
  timeoutSearch;
  searchValue;

  listGroupConfigs = [];
  layoutConfig = []; // layout config

  listOption = [];

  leftList = [];
  rightList = [];

  @ViewChild("searchKey", { static: true })
  searchKey: ElementRef;

  filterCondition: string;
  index: number = -1;

  visibleBtnSelectAll = true;

  constructor(
    private router: Router,
    private tranferSV: TransferDataService,
    private translateSV: AmisTranslationService,
    private activatedRouter: ActivatedRoute,
    private userOptionSV: UserOptionService,
    private amisTransferSV: AmisTransferDataService
  ) {
    super();
  }

  ngOnInit(): void {
    this.getSearchOption(this.router.url);
    this.router.events.subscribe((value) => {
      if (value instanceof NavigationStart) this.getSearchOption(value.url);
    });
    this.activatedRouter.queryParams.subscribe((data) => {
      if (data?.searchvalue && !this.searchKey.nativeElement.value.trim()) {
        this.searchKey.nativeElement.value = data?.searchvalue;
      } else if (!data?.searchvalue) {
        this.searchKey.nativeElement.value = "";
      }

      if (data?.TagName) {
        this.searchOption = data?.TagName;
        this.isShown = true;
      }
    });

    this.listSearchHistory = JSON.parse(
      localStorage.getItem("AMIS_Contact_SearchHistory")
    );
    if (!this.listSearchHistory) {
      this.listSearchHistory = [];
    }

    // check trạng thái icon trên ô tìm kiếm
    this.tranferSV.layoutConfig
      .pipe(takeUntil(this._onDestroySub))
      .subscribe((data) => {
        this.getListOption();
      });
  }

  /**
   * lấy ds tùy chọn tìm kiếm
   * dtnam1 27/05/2020
   */
  getListOption() {
    // xử lý mỗi khi ng dùng mở popover lựa chọn tìm kiếm
    this.layoutConfig = JSON.parse(
      sessionStorage.getItem(`AMIS_Contact_LayoutConfig`)
    );
    if (this.layoutConfig?.length) {
      // if (EmployeeService.userInfo?.UserOptions?.SearchOption?.length) {
      //   this.listOption = EmployeeService.userInfo?.UserOptions.SearchOption;
      // } else {
      this.listOption = this.layoutConfig.map((item) => ({
        Caption: item.Caption,
        DataType: item.DataType,
        FieldName: item.FieldName,
        isSelected: true,
      }));
      EmployeeService.userInfo.UserOptions.SearchOption = this.listOption;
      // }
      this.listOption = this.listOption.filter(
        (item) => item.FieldName != "Empty"
      );
      this.visibleBtnSelectAll = !!this.listOption.find((x) => !x.isSelected);
    }
  }

  onMouseEnter(e) {
    e.classList.add("item-history-focus");
  }
  onMouseLeave(e) {
    e.classList.remove("item-history-focus");
  }

  /**
   * Hàm xử lí khi gõ
   * Created by: HGVinh 26/05/2020
   * @param key key search
   */
  onKeyUp(key, event) {
    if (event.keyCode === KeyCode.Esc) {
      key.value = "";
      key.blur();
    } else if (event.keyCode === KeyCode.ArrowDown) {
      this.onShowSeachHistory();
      let profiles = this.scrollContent.nativeElement.children;
      this.index++;
      if (this.index > this.listSearchHistory.length - 1) {
        this.index = 0;
      }
      for (let i = 0; i < profiles.length; i++) {
        this.onMouseLeave(profiles[i]);
      }
      this.onMouseEnter(this.scrollContent.nativeElement.children[this.index]);
    } else if (event.keyCode === KeyCode.ArrowUp) {
      if (this.listSearchHistory && this.listSearchHistory.length > 0) {
        let profiles = this.scrollContent.nativeElement.children;
        this.index--;
        if (this.index < 0) {
          this.index = this.listSearchHistory.length - 1;
        }
        for (let i = 0; i < profiles.length; i++) {
          this.onMouseLeave(profiles[i]);
        }
        this.onMouseEnter(
          this.scrollContent.nativeElement.children[this.index]
        );
      }
    } else if (event.keyCode === KeyCode.Enter) {
      if (this.index >= 0 && this.showHistory) {
        this.scrollContent.nativeElement.children[this.index].click();
      }
      // event.stopPropagation();
    } else {
      clearTimeout(this.timeoutSearch);
      if (key?.value) {
        // kiểm tra option config trc khi search
        this.searchValue = key?.value;
        let filter = "";
        const searchName = AmisStringUtils.convertVNtoENToLower(
          key?.value.trim()
        );
        let filterCondition = "[";
        let searchColumns = this.listOption
          .filter((x) => x.isSelected)
          .map((x) => x.FieldName);
        if (searchColumns.length) {
          for (let index = 0; index < searchColumns.length; index++) {
            const element = searchColumns[index];
            filter += element + ",";
          }
        }

        UserOptionService.searchOption = filter;

        this.filter = filter;
        this.timeoutSearch = setTimeout(() => {
          this.searchValue = key?.value;
          this.router.navigate(this.checkCurrentUrl(), {
            relativeTo: this.activatedRouter,
            queryParams: {
              searchvalue: key?.value.trim(),
            },
          });
          this.listSearchHistory = JSON.parse(
            localStorage.getItem("AMIS_Contact_SearchHistory")
          );

          if (key?.value.trim()) {
            if (this.listSearchHistory && this.listSearchHistory.length > 0) {
              // if(key?.value.trim() != this.listSearchHistory[0]?.searchValue) {

              const existedIndex = this.listSearchHistory.findIndex(
                (v) => v.searchValue == key?.value.trim()
              );
              if (existedIndex >= 0) {
                this.listSearchHistory.splice(existedIndex, 1);
              }

              if (this.listSearchHistory.length <= 5)
                this.listSearchHistory.length++;
              for (var i = this.listSearchHistory.length - 1; i >= 1; i--) {
                this.listSearchHistory[i] = this.listSearchHistory[i - 1];
              }

              this.listSearchHistory[0] = {
                searchValue: key?.value.trim(),
              };
              // }
            } else {
              this.listSearchHistory = [];
              this.listSearchHistory.push({
                searchValue: key?.value.trim(),
              });
            }

            localStorage.setItem(
              "AMIS_Contact_SearchHistory",
              JSON.stringify(this.listSearchHistory)
            );
            this.showHistory = false;
          }
        }, 700);
      } else {
        this.timeoutSearch = setTimeout(() => {
          this.searchValue = key?.value;
          this.tranferSV.emitCommonSearchValue(key?.value);
          this.router.navigate(this.checkCurrentUrl(), {
            relativeTo: this.activatedRouter,
            queryParams: {
              searchvalue: null,
            },
          });

          if (key?.value.trim()) {
            if (this.listSearchHistory && this.listSearchHistory.length > 0) {
              if (this.listSearchHistory.length <= 4)
                this.listSearchHistory.length++;
              for (var i = this.listSearchHistory.length - 1; i >= 1; i--) {
                this.listSearchHistory[i] = this.listSearchHistory[i - 1];
              }
              this.listSearchHistory[0] = {
                searchValue: key?.value.trim(),
              };
            } else {
              this.listSearchHistory = [];
              this.listSearchHistory.push({
                searchValue: key?.value.trim(),
              });
            }

            localStorage.setItem(
              "AMIS_Contact_SearchHistory",
              JSON.stringify(this.listSearchHistory)
            );
            this.showHistory = false;
          }
        }, 700);
      }
    }
  }

  getSearchOption(url) {
    this.isShown = false;
    if (url.includes("recently")) {
      setTimeout(() => {
        this.searchOption = this.translateSV.getValueByKey(
          "SIDEBAR_RECENT_CONTACTS"
        );
        this.isShown = true;
      }, 100);
    } else if (url.includes("favorite")) {
      setTimeout(() => {
        this.searchOption = this.translateSV.getValueByKey(
          "SIDEBAR_FAVORITE_CONTACTS"
        );
        this.isShown = true;
      }, 100);
    } else if (url.includes("entire")) {
      this.isShown = false;
    }
  }

  /**
   * route đến màn tất cả liên hệ bỏ qua điều kiện lọc
   * nmduy 15/12/2020
   */
  removeSearchOption() {
    this.router.navigate(["entire-contact"], {
      queryParams: {
        searchvalue: this.searchValue ? this.searchValue : null,
      },
    });
    this.isShown = false;
  }

  /**
   * Hàm xử lý khi click vào biểu tượng tùy chỉnh option tìm kiếm
   * Created by ltanh1 09/07/2020
   */
  handleClickSearchBy() {
    if (this.showSearchByOption) {
      this.showSearchByOption = false;
    } else {
      this.showSearchByOption = true;
      this.getListOption();
    }
  }

  /**
   * click checkbox tùy chọn
   * @param item
   * dtnam1 20/11/2020
   */
  handleClickCheckbox(item) {
    let option = this.listOption.find((x) => x.FieldName === item.FieldName);
    if (option) {
      option.isSelected = !option.isSelected;
    }
    this.visibleBtnSelectAll = !!this.listOption.find((x) => !x.isSelected);
  }

  /**
   * Hàm xử lý chọn lấy tất cả các option search
   * Created by ltanh1 10/07/2020
   */
  selectAllOption() {
    this.listOption.forEach((el) => (el.isSelected = true));
    this.visibleBtnSelectAll = false;
  }

  /**
   * Hàm xử lý chọn lấy tất cả các option search
   * Created by dtnam1 10/09/2020
   */
  onClickClearSelect() {
    this.listOption.forEach((el) => (el.isSelected = false));
    this.visibleBtnSelectAll = true;
  }

  /**
   * khi tắt popover setting
   * @param e
   */
  onHiding(e) {
    //chỉnh sửa bời hgvinh: thay đổi cho phép người dùng lưu lại vào database
    if (!this.listOption.find((x) => x.isSelected)) {
      let option = this.listOption.find((x) => x.FieldName === "FullName");
      if (option) {
        option.isSelected = true;
      }
    }
    // xóa option nếu caption null
    this.listOption = this.listOption.filter((x) => x.Caption && x.FieldName);

    let param = {
      SearchOption: this.listOption,
    };
    this.userOptionSV.saveUserOption(param).subscribe((res) => {
      if (res?.Success) {
        // if (this.searchValue) {
        this.searchValue = this.searchKey.nativeElement.value;
        this.tranferSV.emitCommonSearchValue(this.searchValue);
        this.router.navigate(this.checkCurrentUrl(), {
          relativeTo: this.activatedRouter,
          queryParams: {
            searchvalue: this.searchValue.trim(),
            optionChangeTime: new Date().getTime(),
          },
        });
        // }
        this.amisTransferSV.showSuccessToast(
          this.translateSV.getValueByKey("SAVE_SUCCESS")
        );
      } else {
        this.amisTransferSV.showErrorToast(
          this.translateSV.getValueByKey("ERROR_HAPPENED")
        );
      }
    });
    let filter = "";
    let searchColumns = this.listOption
      .filter((x) => x.isSelected)
      .map((x) => x.FieldName);
    if (searchColumns.length) {
      for (let index = 0; index < searchColumns.length; index++) {
        const element = searchColumns[index];
        filter += element + ",";
      }
    }
    this.filter = filter;
    UserOptionService.searchOption = filter;
    // clearTimeout(this.timeoutSearch);
    //dtnam1 sửa 8/6/2020 : thêm case nếu searchValue có giá trị mới load lại data
  }

  /**
   * Xử lý chọn một kết quả đã tìm kiếm
   * Created by ltanh1 16/07/2020
   */
  handleClickSearchHistory(e) {
    clearTimeout(this.timeoutSearch);
    this.timeoutSearch = setTimeout(() => {
      this.searchValue = this.searchKey.nativeElement.value;
      this.tranferSV.emitCommonSearchValue(this.searchValue);
      this.router.navigate(this.checkCurrentUrl(), {
        relativeTo: this.activatedRouter,
        queryParams: {
          searchvalue: e.searchValue,
          searchBy: this.filter,
        },
      });
    }, 700);
    this.searchKey.nativeElement.value = e.searchValue;
    this.showHistory = false;
  }

  /**
   * Hàm xử lý xóa các kết quả đã tìm kiếm
   * Created by ltanh1 16/07/2020
   */
  handleDelete() {
    localStorage.removeItem("AMIS_Contact_SearchHistory");
    this.showHistory = false;
    this.listSearchHistory = [];
  }

  /**
   * hiển thị popover tìm kiếm theo lịch sử
   * nmduy 26/11/2020
   */
  onShowSeachHistory() {
    let profiles = this.scrollContent.nativeElement.children;
    if (this.showHistory === false && profiles.length) {
      this.index = -1;
    }
    this.showHistory = true;
    for (let i = 0; i < profiles.length; i++) {
      if (i != 0) {
        this.onMouseLeave(profiles[i]);
      }
    }
    // if (this.searchValue) {
    //   for (let i = 0; i < this.listSearchHistory.length; i++) {
    //     const element = this.listSearchHistory[i].searchValue;
    //     if (element.trim() == this.searchValue.trim()) {
    //       this.index = i;
    //       this.onMouseEnter(this.scrollContent.nativeElement.children[i]);
    //       return;
    //     }
    //   }
    // }
    // this.index = -1;
  }

  /**
   * kiểm tra url hiện tại
   * nmduy 15/12/2020
   */
  checkCurrentUrl() {
    // nếu đang trong màn thiết lập
    if (this.router.url.includes("setting")) {
      return ["/entire-contact"];
    }
    return [];
  }
}
