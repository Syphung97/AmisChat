import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormatDataPipe } from './format-data.pipe';



@NgModule({
  declarations: [FormatDataPipe],
  imports: [
    CommonModule
  ],
  exports: [FormatDataPipe]
})
export class DataPipeModule { }
