import { Pipe, PipeTransform } from "@angular/core";
import { DataType } from "src/common/models/export/data-type.enum";
import { convertDateToString } from "../../function/common-function";
import { GroupFieldConfig } from "../../models/group-field-config/group-field-config";

@Pipe({
  name: "formatData",
})
export class FormatDataPipe implements PipeTransform {
  transform(value: any, ...args: GroupFieldConfig[]): any {
    const config = args[0];
    if(!value) return "";
    if (
      config.DataType == DataType.DateType ||
      config.DataType == DataType.DateTimeType
    ) {
      const v = new Date(value);
      return convertDateToString(v);
    }
    if (config.DataType == DataType.CurrencyType) {
      if (value) {
        return Number(value)
          .toFixed(2)
          .replace(/\d(?=(\d{3})+\.)/g, "$&,");
      }
    }
    if (config.DataType == DataType.HyperLinkType) {
      return '<a href="' + value + '" target="_blank">' + value + '</a>'
    }
    if(config.DataType == DataType.Email) {
      return `<a href="mailto:${value}">${value} </a>`
    }
    if(config.DataType == DataType.Phone) {
      return `<a href="tel:+${value}">${value} </a>`
    }
    return value;
  }
}
